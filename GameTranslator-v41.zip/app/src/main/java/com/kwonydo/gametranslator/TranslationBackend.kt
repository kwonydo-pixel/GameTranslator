package com.kwonydo.gametranslator

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.File
import java.util.concurrent.Executors

/** JNI contract for an embedded slimt implementation. No network or external app is used. */
interface TranslationBackend {
    val isReady: Boolean
    fun translate(source: String, language: Int, done: (translation: String, error: String?) -> Unit)
    fun close()
}

/**
 * Language packs must be in filesDir/slimt/en-ko or filesDir/slimt/ja-ko.
 * Each pack requires model.bin, vocab.spm, and lex.s2t.bin. Exact model
 * formats and native ABI must match the linked slimt build.
 *
 * This class intentionally does not pretend that a native implementation exists.
 */
class SlimtTranslationBackend(context: Context) : TranslationBackend {
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val models = File(context.filesDir, "slimt")
    private val available: Boolean = try {
        System.loadLibrary("gametranslator_slimt")
        true
    } catch (_: UnsatisfiedLinkError) {
        false
    }
    private var handleEn = 0L
    private var handleJa = 0L

    override val isReady: Boolean get() = available && (handleEn != 0L || handleJa != 0L)

    init {
        if (available) {
            val en = File(models, "en-ko")
            val ja = File(models, "ja-ko")
            if (valid(en)) handleEn = try { nativeOpen(en.absolutePath) } catch (_: Exception) { 0L }
            if (valid(ja)) handleJa = try { nativeOpen(ja.absolutePath) } catch (_: Exception) { 0L }
        }
    }

    private fun valid(folder: File): Boolean =
        listOf("model.bin", "vocab.spm", "lex.s2t.bin").all { File(folder, it).isFile }

    override fun translate(source: String, language: Int, done: (String, String?) -> Unit) {
        val handle = if (language == 0) handleEn else handleJa
        if (handle == 0L) {
            done("", if (!available) "slimt native library not packaged" else "language model not installed")
            return
        }
        worker.execute {
            val result = try { nativeTranslate(handle, source) } catch (_: Exception) { "" }
            main.post { done(result, if (result.isBlank()) "native translation failed" else null) }
        }
    }

    override fun close() {
        worker.shutdown()
        if (available) {
            if (handleEn != 0L) nativeClose(handleEn)
            if (handleJa != 0L) nativeClose(handleJa)
        }
        handleEn = 0L
        handleJa = 0L
    }

    private external fun nativeOpen(modelDirectory: String): Long
    private external fun nativeTranslate(handle: Long, text: String): String
    private external fun nativeClose(handle: Long)
}
