package com.kwonydo.gametranslator

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import com.google.mlkit.nl.translate.*

class MainActivity : Activity() {
    private val captureCode = 1001
    private var language = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 32)
            setBackgroundColor(Color.rgb(20, 26, 40))
        }
        fun title(s: String) = TextView(this).apply { text=s; textSize=19f; setTextColor(Color.WHITE); setPadding(0,12,0,12) }
        root.addView(title("GameTranslator 0.2\n게임 화면 번역 실험판"))
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("영어 → 한국어", "일본어 → 한국어"))
        spinner.onItemSelectedListener = object: android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) { language=position }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        root.addView(spinner)
        val status = title("먼저 번역 모델을 준비하세요.")
        val modelButton = Button(this).apply { text="1. 번역 모델 다운로드 / 준비" }
        modelButton.setOnClickListener {
            val source = if (language==0) TranslateLanguage.ENGLISH else TranslateLanguage.JAPANESE
            val t = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(source).setTargetLanguage(TranslateLanguage.KOREAN).build())
            status.text="모델 준비 중..."
            t.downloadModelIfNeeded().addOnSuccessListener { status.text="모델 준비 완료!"; t.close() }
                .addOnFailureListener { status.text="모델 오류: ${it.message}"; t.close() }
        }
        root.addView(modelButton)
        val start = Button(this).apply { text="2. 화면 번역 시작" }
        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "다른 앱 위에 표시 권한을 허용하고 돌아오세요", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), captureCode)
            }
        }
        root.addView(start)
        val stop = Button(this).apply { text="번역 종료" }
        stop.setOnClickListener { stopService(Intent(this, CaptureService::class.java)); status.text="번역 종료" }
        root.addView(stop)
        root.addView(status)
        root.addView(title("시작 후 화면의 '영역 선택' 버튼을 누르고 번역할 사각형을 그리세요. 여러 개를 그린 뒤 완료를 누르면 자동 번역합니다."))
        setContentView(root)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode==captureCode && resultCode==RESULT_OK && data!=null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("resultData", data)
                putExtra("language", language)
            }
            if (Build.VERSION.SDK_INT>=26) startForegroundService(service) else startService(service)
            Toast.makeText(this, "번역 시작! 다른 앱으로 이동하세요.", Toast.LENGTH_LONG).show()
        }
    }
}
