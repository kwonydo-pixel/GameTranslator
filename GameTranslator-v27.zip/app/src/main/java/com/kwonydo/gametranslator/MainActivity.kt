package com.kwonydo.gametranslator

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val captureCode = 1001
    private var language = 0
    private var statusView: TextView? = null
    private var detailView: TextView? = null
    private val diagnosticReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val message = intent?.getStringExtra("message") ?: return
            statusView?.text = "Gemma 진단: $message"
            refreshDetail()
        }
    }
    private fun refreshDetail() {
        val prefs = getSharedPreferences("gemma_diagnostics", MODE_PRIVATE)
        detailView?.text = prefs.getString("last_result", "아직 번역 결과 없음")
    }
    override fun onResume() {
        super.onResume()
        val message = getSharedPreferences("gemma_diagnostics", MODE_PRIVATE).getString("latest", null)
        if (message != null) statusView?.text = "Gemma 진단: $message"
        refreshDetail()
        val filter = IntentFilter("com.kwonydo.gametranslator.GEMMA_STATUS")
        androidx.core.content.ContextCompat.registerReceiver(this, diagnosticReceiver, filter, androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED)
    }
    override fun onPause() {
        try { unregisterReceiver(diagnosticReceiver) } catch (_: Exception) {}
        super.onPause()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val saved = getSharedPreferences("translator_settings", MODE_PRIVATE)
        language = saved.getInt("language", 0).coerceIn(0, 1)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 32)
            setBackgroundColor(Color.rgb(20, 26, 40))
        }
        fun title(s: String) = TextView(this).apply { text=s; textSize=19f; setTextColor(Color.WHITE); setPadding(0,12,0,12) }
        root.addView(title("GameTranslator 0.26\n게임 화면 번역"))
        fun readableAdapter(items: List<String>): ArrayAdapter<String> = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            override fun getView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                return super.getView(position, convertView, parent).also { (it as? TextView)?.setTextColor(Color.WHITE) }
            }
            override fun getDropDownView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                return super.getDropDownView(position, convertView, parent).also {
                    (it as? TextView)?.setTextColor(Color.BLACK)
                    it.setBackgroundColor(Color.WHITE)
                }
            }
        }.apply { setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        fun selectorBackground(): GradientDrawable = GradientDrawable().apply {
            setColor(Color.rgb(40, 53, 75))
            cornerRadius = 18f
            setStroke(3, Color.rgb(91, 153, 245))
        }
        fun selectionLabel(text: String) = TextView(this).apply {
            this.text = text; textSize = 15f; setTextColor(Color.rgb(186, 208, 237))
            setPadding(0, 22, 0, 9)
        }
        root.addView(selectionLabel("번역 언어 선택  ▾"))
        val spinner = Spinner(this).apply {
            background = selectorBackground()
            setPadding(24, 12, 24, 12)
            minimumHeight = 112
        }
        spinner.adapter = readableAdapter(listOf("영어 → 한국어", "일본어 → 한국어"))
        spinner.onItemSelectedListener = object: android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) { language=position; saved.edit().putInt("language", position).apply() }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        spinner.setSelection(language)
        root.addView(spinner)
        root.addView(selectionLabel("번역 엔진: Gemma 3 1B 전용"))
        val status = title("진단 대기 중. 번역을 시작하면 Gemma 상태가 여기에 표시됩니다.")
        status.textSize = 16f
        status.setTextColor(Color.rgb(255, 216, 133))
        statusView = status
        val start = Button(this).apply { text="화면 번역 시작" }
        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "다른 앱 위에 표시 권한을 허용하고 돌아오세요", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), captureCode)
            }
        }
        root.addView(start)
        val stop = Button(this).apply { text="번역 종료" }
        stop.setOnClickListener { stopService(Intent(this, CaptureService::class.java)); status.text="번역 종료" }
        root.addView(stop)
        root.addView(status)
        val detail = title("아직 번역 결과 없음")
        detail.textSize = 14f
        detailView = detail
        root.addView(title("Gemma 최근 번역 상세 (원문 / 결과 / 길이)"))
        root.addView(detail)
        refreshDetail()
        root.addView(title("Gemma 진단 기록은 앱을 다시 열어도 확인할 수 있습니다."))
        root.addView(title("시작 후 화면의 '영역 선택' 버튼을 누르고 번역할 사각형을 그리세요. 여러 개를 그린 뒤 완료를 누르면 자동 번역합니다."))
        setContentView(root)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode==captureCode && resultCode==RESULT_OK && data!=null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("resultData", data)
                putExtra("language", language)
                putExtra("engine", 1)
            }
            if (Build.VERSION.SDK_INT>=26) startForegroundService(service) else startService(service)
            Toast.makeText(this, "번역 시작! 다른 앱으로 이동하세요.", Toast.LENGTH_LONG).show()
        }
    }
}
