# v70: OPUS-MT model verification stage

The Android overlay is still ML Kit and has NOT been switched to OPUS-MT.
This package contains the previous v69 Android source plus `opus_eval/test_opus.py`.
Run `v70.yml` in GitHub Actions to discover available Helsinki-NLP direct English/Japanese-to-Korean models, validate language metadata, and run real sample translations. Results are uploaded as an artifact.

If no direct OPUS-MT model is found, the test explicitly reports NO_VERIFIED_DIRECT_MODEL. It will NOT pretend that a different direction model works.

This is a model-selection/quality-test deliverable, NOT an OPUS-MT Android APK implementation.
