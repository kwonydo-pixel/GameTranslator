package com.kwonydo.gametranslator

import android.content.Context
import ai.onnxruntime.*
import org.json.JSONObject
import java.io.File
import java.nio.LongBuffer
import java.util.concurrent.Executors

/** Experimental offline M2M100 ONNX runtime. Uses vocab-ranked SentencePiece BPE. */
class M2mEngine(private val context: Context) {
    private val executor = Executors.newSingleThreadExecutor()
    private val root = File(context.filesDir, "m2m100")
    private val names = listOf("encoder_model.onnx", "decoder_model.onnx", "sentencepiece.bpe.model", "vocab.json")
    fun ready(): Boolean = names.all { File(root,it).isFile }
    fun translate(source:String, language:Int, callback:(String,String?)->Unit) {
        executor.execute {
            try { callback(infer(source, language),null) }
            catch(e:Exception) { callback("", "M2M100 실행 실패: ${e.message}") }
        }
    }
    private fun infer(source:String,language:Int):String {
        check(ready()) { "모델 4개 파일을 먼저 다운로드하세요" }
        val vocabJson=JSONObject(File(root,"vocab.json").readText())
        val ids=HashMap<String,Int>()
        val reverse=HashMap<Int,String>()
        val keys=vocabJson.keys()
        while(keys.hasNext()) { val k=keys.next(); val v=vocabJson.getInt(k); ids[k]=v; reverse[v]=k }
        val srcId=if(language==1) 128046L else 128022L
        val koId=128050L
        val pieces=encode(source,ids)
        val input=longArrayOf(srcId)+pieces.map{it.toLong()}.toLongArray()+longArrayOf(2L)
        val mask=LongArray(input.size){1L}
        val env=OrtEnvironment.getEnvironment()
        val opts=OrtSession.SessionOptions().apply { setIntraOpNumThreads(2) }
        env.createSession(File(root,names[0]).absolutePath,opts).use { enc ->
          env.createSession(File(root,names[1]).absolutePath,opts).use { dec ->
            OnnxTensor.createTensor(env, arrayOf(input)).use { sourceTensor ->
              OnnxTensor.createTensor(env,arrayOf(mask)).use { maskTensor ->
                enc.run(mapOf("input_ids" to sourceTensor,"attention_mask" to maskTensor)).use { encoderResult ->
                  val hidden=encoderResult[0] as OnnxTensor
                  val tokens=ArrayList<Long>().apply { add(2L);add(koId) }
                  for(step in 0 until 160) {
                    OnnxTensor.createTensor(env,arrayOf(tokens.toLongArray())).use { decoderIds ->
                      dec.run(mapOf("input_ids" to decoderIds,"encoder_hidden_states" to hidden,"encoder_attention_mask" to maskTensor)).use { output ->
                        val logits=output[0].value as Array<Array<FloatArray>>
                        val last=logits[0].last()
                        var best=0
                        for(i in 1 until last.size) if(last[i]>last[best]) best=i
                        if(best==2) return decode(tokens.drop(2).map{it.toInt()},reverse)
                        tokens.add(best.toLong())
                      }
                    }
                  }
                  return decode(tokens.drop(2).map{it.toInt()},reverse)
                }
              }
            }
          }
        }
    }
    private fun encode(text:String,vocab:Map<String,Int>):List<Int> {
        val raw=("▁"+text.trim().replace(Regex("\\s+"),"▁"))
        val parts=raw.codePoints().toArray().map{String(Character.toChars(it))}.toMutableList()
        // SentencePiece BPE: merge the lowest-ranked vocabulary piece until no pair matches.
        while(parts.size>1) {
            var idx=-1; var rank=Int.MAX_VALUE
            for(i in 0 until parts.size-1) {
                val r=vocab[parts[i]+parts[i+1]] ?: continue
                if(r<rank){rank=r;idx=i}
            }
            if(idx<0) break
            parts[idx]+=parts[idx+1];parts.removeAt(idx+1)
        }
        return parts.map { vocab[it] ?: vocab["<unk>"] ?: 3 }
    }
    private fun decode(ids:List<Int>,vocab:Map<Int,String>):String = ids.mapNotNull{vocab[it]}
      .filterNot{it.startsWith("__") || it.startsWith("<")}
      .joinToString("").replace("▁"," ").trim()
}
