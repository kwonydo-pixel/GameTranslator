"""Validate actual OPUS-MT source->Korean models before Android integration.
Run: python opus_eval/test_opus.py
"""
import json
import time
from pathlib import Path
from huggingface_hub import HfApi
from transformers import MarianMTModel, MarianTokenizer

SAMPLES = {
    'en': [
        'Choose your class.',
        'The sun rose again today.',
        'I lost my key somewhere in the forest.',
        'You must clear this stage before moving on.',
        'We need to retreat before the enemy arrives.',
    ],
    'ja': [
        '今日も太陽が昇った。',
        '職業を選択してください。',
        '森のどこかで鍵をなくしてしまった。',
        '敵が来る前に撤退しよう。',
    ],
}

# No guessed URLs or models: use HF metadata and verify that the selected
# model explicitly lists source and target languages in its model card.
api = HfApi()
output = {}
for lang, samples in SAMPLES.items():
    candidates = []
    for item in api.list_models(author='Helsinki-NLP', search='opus-mt', limit=5000):
        name = item.id
        # Prefer direct language-pair naming, but never infer a nonexistent repo.
        suffix = name.rsplit('/', 1)[-1]
        if not (suffix.startswith(f'opus-mt-{lang}-') or suffix.startswith(f'opus-mt-{"jpn" if lang == "ja" else "eng"}-')):
            continue
        try:
            info = api.model_info(name)
            langs = set(info.card_data.get('language', []) if info.card_data else [])
            if lang in langs and 'ko' in langs:
                candidates.append(name)
        except Exception as exc:
            print(f'Cannot inspect {name}: {exc}')
    if not candidates:
        output[lang] = {'status': 'NO_VERIFIED_DIRECT_MODEL', 'candidates': []}
        print(f'No verified OPUS-MT {lang}->ko model found. No substitute or pivot used.')
        continue
    model_id = sorted(candidates, key=lambda x: (x.endswith(f'{lang}-ko') is False, len(x)))[0]
    print(f'Loading {model_id}', flush=True)
    tokenizer = MarianTokenizer.from_pretrained(model_id)
    model = MarianMTModel.from_pretrained(model_id).eval()
    results = []
    for sentence in samples:
        start = time.perf_counter()
        inputs = tokenizer([sentence], return_tensors='pt', truncation=True)
        generated = model.generate(**inputs, max_new_tokens=128, num_beams=4)
        translation = tokenizer.batch_decode(generated, skip_special_tokens=True)[0]
        result = {'source': sentence, 'translation': translation, 'seconds': round(time.perf_counter()-start, 3)}
        print(json.dumps(result, ensure_ascii=False), flush=True)
        results.append(result)
    output[lang] = {'status': 'TESTED_ON_RUNNER', 'model': model_id, 'results': results}
Path('opus_eval_results.json').write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding='utf-8')
