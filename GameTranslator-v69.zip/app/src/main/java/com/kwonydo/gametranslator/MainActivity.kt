package com.kwonydo.gametranslator

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.*

class MainActivity : Activity() {
    private val captureCode = 1001
    private var language = 0
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("translator_settings", MODE_PRIVATE)
        language = prefs.getInt("language", 0).coerceIn(0, 1)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 42, 36, 36)
            setBackgroundColor(Color.rgb(20, 26, 40))
        }
        fun label(value: String, size: Float = 16f) = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(Color.WHITE)
            setPadding(0, 14, 0, 14)
        }
        fun background() = GradientDrawable().apply {
            setColor(Color.rgb(40, 53, 75))
            cornerRadius = 18f
            setStroke(2, Color.rgb(91, 153, 245))
        }
        root.addView(label("GameTranslator v69", 23f))
        root.addView(label("번역 언어"))
        val spinner = Spinner(this).apply {
            background = background()
            setPadding(20, 12, 20, 12)
            minimumHeight = 100
        }
        val items = listOf("영어 → 한국어", "일본어 → 한국어")
        spinner.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            override fun getView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup) =
                super.getView(position, convertView, parent).also { (it as TextView).setTextColor(Color.WHITE) }
            override fun getDropDownView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup) =
                super.getDropDownView(position, convertView, parent).also {
                    (it as TextView).setTextColor(Color.BLACK)
                    it.setBackgroundColor(Color.WHITE)
                }
        }.apply { setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        spinner.setSelection(language)
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                language = position
                prefs.edit().putInt("language", position).apply()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        root.addView(spinner)
        root.addView(Button(this).apply {
            text = "화면 번역 시작"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "다른 앱 위에 표시 권한을 허용해 주세요", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    startActivityForResult(manager.createScreenCaptureIntent(), captureCode)
                }
            }
        })
        root.addView(Button(this).apply {
            text = "화면 번역 종료"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                status.text = "화면 번역 종료됨"
            }
        })
        root.addView(Button(this).apply {
            text = "M2M100 번역 테스트"
            setOnClickListener { startActivity(Intent(this@MainActivity, M2mTestActivity::class.java)) }
        })
        status = label("게임 화면 번역: ML Kit / M2M100: 별도 테스트")
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureCode && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("resultData", data)
                putExtra("language", language)
                putExtra("engine", 0)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
            status.text = "화면 번역 실행 중"
            Toast.makeText(this, "번역 시작! 게임으로 이동하세요.", Toast.LENGTH_LONG).show()
        }
    }
}
