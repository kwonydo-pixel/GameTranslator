package com.kwonydo.gametranslator

import android.app.*
import android.content.*
import android.graphics.*
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.nl.translate.*

class CaptureService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: android.hardware.display.VirtualDisplay? = null
    private var translator: Translator? = null
    private var recognizer: com.google.mlkit.vision.text.TextRecognizer? = null
    private var control: View? = null
    private var labels = mutableListOf<View>()
    private var chooser: View? = null
    private val regions = mutableListOf<Rect>()
    private var busy = false
    private var ready = false
    private var widthPx = 0
    private var heightPx = 0
    private var dpi = 0
    private val tick = object: Runnable {
        override fun run() {
            if (ready && !busy && chooser==null && regions.isNotEmpty()) scan()
            handler.postDelayed(this, 2200)
        }
    }
    override fun onBind(intent: Intent?) = null
    override fun onCreate() { super.onCreate(); wm=getSystemService(WINDOW_SERVICE) as WindowManager }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection!=null) return START_NOT_STICKY
        val channel="game_translator"
        val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(channel,"게임 화면 번역",NotificationManager.IMPORTANCE_LOW))
        val notification=Notification.Builder(this,channel).setContentTitle("GameTranslator 작동 중").setContentText("번역 중, 앱에서 종료할 수 있습니다").setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT>=29) startForeground(1,notification,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(1,notification)
        val lang=intent?.getIntExtra("language",0) ?: 0
        val src=if(lang==0) TranslateLanguage.ENGLISH else TranslateLanguage.JAPANESE
        translator=Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(TranslateLanguage.KOREAN).build())
        recognizer=if(lang==0) TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) else TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        translator?.downloadModelIfNeeded()?.addOnSuccessListener { ready=true }?.addOnFailureListener { toast("번역 모델 다운로드 실패") }
        val metrics=resources.displayMetrics
        widthPx=metrics.widthPixels; heightPx=metrics.heightPixels; dpi=metrics.densityDpi
        reader=ImageReader.newInstance(widthPx,heightPx,android.graphics.PixelFormat.RGBA_8888,2)
        val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        val data=if(Build.VERSION.SDK_INT>=33) intent?.getParcelableExtra("resultData",Intent::class.java) else intent?.getParcelableExtra("resultData")
        if(data==null) { stopSelf(); return START_NOT_STICKY }
        projection=mgr.getMediaProjection(intent?.getIntExtra("resultCode",Activity.RESULT_OK) ?: Activity.RESULT_OK,data)
        projection?.registerCallback(object: MediaProjection.Callback() { override fun onStop() { handler.post { stopSelf() } } },handler)
        display=projection?.createVirtualDisplay("GameTranslator",widthPx,heightPx,dpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader?.surface,null,handler)
        showControl()
        handler.postDelayed(tick,2500)
        return START_NOT_STICKY
    }
    private fun params(w:Int,h:Int,flags:Int=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE): WindowManager.LayoutParams =
        WindowManager.LayoutParams(w,h,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,flags,android.graphics.PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.LEFT }
    private fun showControl() {
        val bar=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setBackgroundColor(Color.argb(220,24,35,52)) }
        val select=Button(this).apply { text="영역 선택"; setOnClickListener { selectRegions() } }
        val clear=Button(this).apply { text="초기화"; setOnClickListener { regions.clear(); clearLabels(); toast("영역 초기화") } }
        val stop=Button(this).apply { text="종료"; setOnClickListener { stopSelf() } }
        bar.addView(select);bar.addView(clear);bar.addView(stop)
        val p=params(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT)
        p.y=(resources.displayMetrics.density*48).toInt()
        wm.addView(bar,p);control=bar
    }
    private fun selectRegions() {
        clearLabels()
        val selection=SelectionView(this,regions) { finish ->
            val v=chooser
            if(v!=null) { wm.removeView(v); chooser=null }
            if(finish) toast("${regions.size}개 영역 자동 번역 시작")
        }
        chooser=selection
        wm.addView(selection,params(widthPx,heightPx,WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE))
    }
    private fun clearLabels() { labels.forEach { try { wm.removeView(it) } catch (_:Exception) {} }; labels.clear() }
    private fun scan() {
        val image=reader?.acquireLatestImage() ?: return
        busy=true
        try {
            val plane=image.planes[0]
            val buffer=plane.buffer
            val stride=plane.rowStride
            val pixelStride=plane.pixelStride
            val bitmap=Bitmap.createBitmap(widthPx+((stride-pixelStride*widthPx)/pixelStride),heightPx,Bitmap.Config.ARGB_8888)
            bitmap.copyPixelsFromBuffer(buffer)
            val cropped=Bitmap.createBitmap(bitmap,0,0,widthPx,heightPx)
            image.close(); bitmap.recycle()
            clearLabels()
            recognizer?.process(InputImage.fromBitmap(cropped,0))?.addOnSuccessListener { result ->
                val blocks=result.textBlocks.flatMap { it.lines }.filter { line ->
                    val r=line.boundingBox
                    r!=null && regions.any { it.intersects(r.left,r.top,r.right,r.bottom) }
                }.take(25)
                if(blocks.isEmpty()) { busy=false; cropped.recycle(); return@addOnSuccessListener }
                var pending=blocks.size
                blocks.forEach { line ->
                    translator?.translate(line.text)?.addOnSuccessListener { translated ->
                        val r=line.boundingBox
                        if(r!=null && translated.isNotBlank()) showLabel(translated,r)
                    }?.addOnCompleteListener { pending--; if(pending==0) { busy=false; cropped.recycle() } }
                }
            }?.addOnFailureListener { busy=false; cropped.recycle() }
        } catch (_:Exception) { image.close(); busy=false }
    }
    private fun showLabel(value:String,r:Rect) {
        if(chooser!=null) return
        val label=TextView(this).apply {
            text=value; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(18,23,32)); textSize=14f
            setPadding(3,1,3,1); maxLines=4
        }
        val p=params(r.width().coerceAtLeast(80),WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN)
        p.x=r.left.coerceAtLeast(0);p.y=r.top.coerceAtLeast(0)
        try { wm.addView(label,p);labels.add(label) } catch (_:Exception) {}
    }
    private fun toast(msg:String) { Toast.makeText(this,msg,Toast.LENGTH_SHORT).show() }
    override fun onDestroy() {
        handler.removeCallbacks(tick)
        clearLabels()
        chooser?.let { try { wm.removeView(it) } catch (_:Exception) {} }
        control?.let { try { wm.removeView(it) } catch (_:Exception) {} }
        display?.release();reader?.close();projection?.stop();translator?.close();recognizer?.close()
        super.onDestroy()
    }
}

private class SelectionView(context:Context, private val regions:MutableList<Rect>, private val finish:(Boolean)->Unit): View(context) {
    private val paint=Paint(3)
    private var sx=0f;private var sy=0f;private var ex=0f;private var ey=0f;private var drawing=false
    override fun onDraw(canvas:Canvas) {
        canvas.drawColor(Color.argb(85,0,0,0))
        paint.color=Color.CYAN;paint.style=Paint.Style.STROKE;paint.strokeWidth=4f
        regions.forEach { canvas.drawRect(it,paint) }
        if(drawing) canvas.drawRect(sx,sy,ex,ey,paint)
        paint.style=Paint.Style.FILL;paint.color=Color.WHITE;paint.textSize=44f
        canvas.drawText("드래그: 영역 추가",24f,110f,paint)
        paint.color=Color.rgb(35,110,210)
        canvas.drawRoundRect(width-245f,28f,width-18f,145f,18f,18f,paint)
        paint.color=Color.WHITE;paint.textSize=48f
        canvas.drawText("완료",width-215f,103f,paint)
    }
    override fun onTouchEvent(e:MotionEvent):Boolean {
        when(e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if(e.x>width-260 && e.y<160) { finish(true);return true }
                sx=e.x;sy=e.y;ex=sx;ey=sy;drawing=true;invalidate();return true
            }
            MotionEvent.ACTION_MOVE -> { if(drawing) { ex=e.x;ey=e.y;invalidate() };return true }
            MotionEvent.ACTION_UP -> {
                if(drawing) {
                    ex=e.x;ey=e.y;drawing=false
                    val r=Rect(minOf(sx,ex).toInt(),minOf(sy,ey).toInt(),maxOf(sx,ex).toInt(),maxOf(sy,ey).toInt())
                    if(r.width()>30 && r.height()>20) regions.add(r)
                    invalidate()
                };return true
            }
        }
        return true
    }
}
