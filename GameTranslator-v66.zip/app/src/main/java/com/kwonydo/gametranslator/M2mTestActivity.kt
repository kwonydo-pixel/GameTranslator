package com.kwonydo.gametranslator

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.widget.*
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.io.FileOutputStream
import java.util.concurrent.Executors

class M2mTestActivity:Activity() {
 private val worker=Executors.newSingleThreadExecutor()
 private lateinit var info:TextView
 private lateinit var input:EditText
 private lateinit var output:TextView
 private lateinit var download:Button
 private lateinit var progress:ProgressBar
 private val engine by lazy { M2mEngine(applicationContext) }
 private val base="https://huggingface.co/Hosstia/m2m100-418m-onnx/resolve/main/m2m100_onnx_v2/"
 private val files=listOf("encoder_model_int8.onnx","decoder_model_int8.onnx","vocab.json")
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
  val root=LinearLayout(this).apply { orientation=1;setPadding(28,32,28,28);setBackgroundColor(Color.rgb(20,26,40)) }
  fun text(s:String)=TextView(this).apply {text=s;textSize=17f;setTextColor(Color.WHITE);setPadding(0,12,0,12)}
  root.addView(text("M2M100 418M 오프라인 번역 실험 (v66)"))
  info=text("모델 상태 확인 중");root.addView(info)
  download=Button(this).apply {text="M2M100 모델 다운로드 (약 760MB)"};root.addView(download)
  progress=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100};root.addView(progress)
  val languages=Spinner(this);languages.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("영어 → 한국어","일본어 → 한국어"));root.addView(languages)
  input=EditText(this).apply {hint="영어 또는 일본어 입력";setTextColor(Color.WHITE);setHintTextColor(Color.LTGRAY);minLines=3};root.addView(input)
  val go=Button(this).apply{text="M2M100 실제 번역 실행"};root.addView(go)
  output=text("번역 결과가 여기에 표시됩니다");root.addView(output)
  val scroll=ScrollView(this).apply{addView(root)};setContentView(scroll)
  fun status(){info.text=if(engine.ready()) "모델 파일 준비됨" else "모델 파일 없음. 다운로드가 필요합니다."}
  status()
  download.setOnClickListener { download.isEnabled=false;worker.execute {
   try {
    val dir=File(filesDir,"m2m100").apply{mkdirs()}
    for((index,name) in files.withIndex()) {
      val dest=File(dir,name)
      if(dest.length()>1000) continue
      val conn=URL(base+name).openConnection() as HttpURLConnection
      conn.connectTimeout=25000;conn.readTimeout=60000;conn.instanceFollowRedirects=true
      if(conn.responseCode !in 200..299) error("HTTP ${conn.responseCode}: $name")
      val total=conn.contentLengthLong;var done=0L
      val tmp=File(dir,"$name.part")
      conn.inputStream.use{ins->FileOutputStream(tmp).use{out->
       val buffer=ByteArray(131072);var n:Int
       while(ins.read(buffer).also{n=it}!=-1){out.write(buffer,0,n);done+=n
        val percent=if(total>0)(done*100/total).toInt().coerceIn(0,100) else 0
        if(done%1048576<131072)runOnUiThread{progress.progress=percent;info.text="${index+1}/3 $name ${done/1000000}MB / ${if(total>0)total/1000000 else 0}MB ($percent%)"}
       }
      }}
      if(total>0 && done!=total) error("불완전한 다운로드: $name")
      if(!tmp.renameTo(dest))error("파일 저장 실패: $name")
      conn.disconnect()
    }
    runOnUiThread{status();download.isEnabled=true}
   }catch(e:Exception){runOnUiThread{info.text="다운로드 실패: ${e.message}";download.isEnabled=true}}
  }}
  go.setOnClickListener {output.text="M2M100 추론 중...";val t=System.currentTimeMillis();engine.translate(input.text.toString(),languages.selectedItemPosition){result,error->runOnUiThread{output.text=if(error!=null)error else "${result} (${(System.currentTimeMillis()-t)/1000.0}초)"}}}
 }
}
