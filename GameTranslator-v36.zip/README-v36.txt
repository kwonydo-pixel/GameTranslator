v36: replace deprecated kotlinOptions jvmTarget string with Kotlin compilerOptions DSL JvmTarget.JVM_17. Build not verified.
