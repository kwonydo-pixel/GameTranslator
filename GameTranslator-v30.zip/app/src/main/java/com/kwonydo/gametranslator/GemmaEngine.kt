package com.kwonydo.gametranslator

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File
import java.util.concurrent.Executors

/** Single-owner Gemma inference engine. OCR and overlays never call MediaPipe directly. */
class GemmaEngine(private val context: Context) {
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var llm: LlmInference? = null
    @Volatile private var closed = false

    fun initialize(done: (Boolean, String) -> Unit) {
        worker.execute {
            var message = "Gemma 모델 준비 완료"
            val success = try {
                val model = prepareBundledModel(context)
                val options = LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(model.absolutePath)
                    .setMaxTokens(256)
                    .build()
                llm?.close()
                llm = LlmInference.createFromOptions(context, options)
                true
            } catch (e: Throwable) {
                Log.e("GameTranslatorGemma", "Model initialization", e)
                message = "초기화 실패: ${e.javaClass.simpleName}: ${e.message ?: "원인 미상"}"
                false
            }
            done(success, message)
        }
    }

    fun translate(text: String, language: Int, done: (String, String?, String) -> Unit) {
        if (closed) { done("", "Gemma 엔진 종료됨", ""); return }
        worker.execute {
            var raw = ""
            var error: String? = null
            var translation = ""
            try {
                val source = if (language == 0) "English" else "Japanese"
                val input = text.replace(Regex("[\\r\\n]+"), " ").trim().take(300)
                val model = llm ?: throw IllegalStateException("Gemma가 초기화되지 않았습니다")
                // Gemma IT task uses Gemma conversation delimiters. Avoid a system turn.
                val prompt = "<start_of_turn>user\n" +
                    "You are translating text from a video game. Translate the $source text into Korean. " +
                    "Reply with ONLY the Korean translation. No explanation, no English, no labels.\n" +
                    "Text: $input<end_of_turn>\n<start_of_turn>model\n"
                raw = model.generateResponse(prompt)
                translation = normalize(raw, input)
                if (translation.isEmpty()) {
                    error = if (raw.isBlank()) "모델 응답 0자 (추론/프롬프트 확인 필요)" else "한국어 번역 추출 실패 (원본 응답 확인)"
                }
            } catch (e: Throwable) {
                Log.e("GameTranslatorGemma", "Inference", e)
                error = "추론 실패: ${e.javaClass.simpleName}: ${e.message ?: "원인 미상"}"
            }
            done(translation, error, raw)
        }
    }

    private fun normalize(raw: String, source: String): String {
        val cleaned = raw.substringBefore("<end_of_turn>")
            .substringBefore("<start_of_turn>")
            .replace(Regex("(?i)^\\s*(korean|translation|번역)\\s*[:：]\\s*"), "")
            .replace(Regex("[\\r\\n]+"), " ")
            .trim().trim('"', '\'')
        if (cleaned.isEmpty() || cleaned.length > maxOf(100, source.length * 4)) return ""
        if (!cleaned.any { it in '\uAC00'..'\uD7A3' }) return ""
        if (cleaned.contains("**") || cleaned.contains("<start_of_turn>")) return ""
        return cleaned
    }

    fun close() {
        closed = true
        worker.execute { try { llm?.close() } catch (_: Exception) {} }
        worker.shutdown()
    }

    companion object {
        private const val FILE_NAME = "Gemma3-1B-IT_multi-prefill-seq_q4_ekv2048.task"
        private const val EXPECTED_BYTES = 554661246L
        fun modelFile(context: Context): File = File(context.filesDir, FILE_NAME)
        private fun prepareBundledModel(context: Context): File {
            val target = modelFile(context)
            if (target.length() == EXPECTED_BYTES) return target
            val temporary = File(context.filesDir, "$FILE_NAME.tmp")
            try {
                context.assets.open(FILE_NAME).use { input ->
                    temporary.outputStream().use { output -> input.copyTo(output, 256 * 1024) }
                }
                check(temporary.length() == EXPECTED_BYTES) { "내장 모델 크기 오류" }
                if (target.exists()) target.delete()
                check(temporary.renameTo(target)) { "모델 설치 실패" }
            } finally { temporary.delete() }
            return target
        }
    }
}
