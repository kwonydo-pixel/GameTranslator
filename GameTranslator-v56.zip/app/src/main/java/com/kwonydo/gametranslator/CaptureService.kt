package com.kwonydo.gametranslator

import android.app.*
import android.content.*
import android.content.res.Configuration
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.*
import android.text.TextUtils
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import kotlin.math.*

class CaptureService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var recognizer: com.google.mlkit.vision.text.TextRecognizer? = null
    private var bubble: View? = null
    private var menu: View? = null
    private var chooser: View? = null
    private val labels = mutableListOf<View>()
    private val labelKeys = mutableMapOf<String, TextView>()
    private val missedScans = mutableMapOf<String, Int>()
    private val labelBounds = mutableMapOf<String, Rect>()
    private val labelSource = mutableMapOf<String, String>()
    private val labelLastSeen = mutableMapOf<String, Int>()
    private var scanSerial = 0
    // A transient OCR variation must not replace a stable translation.
    private val candidateSource = mutableMapOf<String, String>()
    private val candidateHits = mutableMapOf<String, Int>()
    private val lastSeenBounds = mutableMapOf<String, Rect>()
    private var language = 0
    private var qwenMode = false
    private var hybridMode = false
    private var aiTranslator: QwenTranslationBackend? = null
    private var aiActiveSource: String? = null
    private val aiCache = object : LinkedHashMap<String, String>(128, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean = size > 128
    }
    private val aiFailedUntil = mutableMapOf<String, Long>()
    private var aiStartedAt = 0L
    private var aiSession = 0
    private var aiStatus = "AI 준비 중"
    private fun startAiIfNeeded(pending: List<Pair<String, String>>) {
        if (!hybridMode || aiActiveSource != null || !translationEnabled) return
        val backend = aiTranslator ?: return
        if (!backend.isReadyFor(language)) {
            aiStatus = backend.statusMessage
            return
        }
        val now = android.os.SystemClock.elapsedRealtime()
        val source = pending.asSequence().map { it.second }.distinct().firstOrNull {
            it.isNotBlank() && aiCache["$language|$it"] == null &&
                (aiFailedUntil["$language|$it"] ?: 0L) <= now
        } ?: return
        aiActiveSource = source
        aiStartedAt = now
        val session = aiSession
        aiStatus = "AI 보정 중"
        backend.translate(source, language) { result, error -> handler.post {
            if (session != aiSession || !hybridMode) return@post
            if (aiActiveSource == source) aiActiveSource = null
            val key = "$language|$source"
            if (result.isNotBlank()) {
                aiCache[key] = result
                aiStatus = "AI 보정 완료"
                // Only upgrade labels whose latest OCR source still matches.
                for ((labelKey, currentSource) in labelSource.toMap()) {
                    if (currentSource != source || !translationEnabled || chooser != null) continue
                    val label = labelKeys[labelKey] ?: continue
                    if (label.text.toString() != result) label.text = result
                }
            } else {
                aiFailedUntil[key] = android.os.SystemClock.elapsedRealtime() + 60000L
                aiStatus = "AI 보정 실패: ${error ?: "빈 결과"}"
                android.util.Log.w("GameTranslator-Hybrid", aiStatus)
            }
        } }
    }
    private var qwenStatus = "AI 로딩"
    private var lastDiagnostics = "AI 시작 대기 중"
    private fun updateQwenStatus(label: String, details: String = label) {
        if (!qwenMode) return
        if (qwenStatus != label || lastDiagnostics != details) {
            qwenStatus = label
            lastDiagnostics = details
            android.util.Log.i("GameTranslator-Qwen", details)
            (bubble as? TextView)?.apply {
                text = label
                textSize = if (label.length > 4) 10f else 12f
            }
        }
    }
    private lateinit var translator: TranslationBackend
    private val regions = mutableListOf<RectF>() // Coordinates in the overlay's current window
    private var busy = false
    // One complete OCR snapshot is translated and committed atomically.
    private var activeTranslation: String? = null
    private var latestSnapshot: String = ""
    private var lastOcrStarted = 0L
    private val translationCache = object : LinkedHashMap<String, String>(128, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean = size > 128
    }
    private val failedUntil = mutableMapOf<String, Long>()
    private var ready = false
    private var captureWidth = 0
    private var captureHeight = 0
    private var overlayWidth = 0
    private var overlayHeight = 0
    private var dpi = 0
    private var bubbleX = 0
    private var bubbleY = 150
    private var translationEnabled = true
    private var expanded = false
    private var generation = 0

    private val tick = object : Runnable {
        override fun run() {
            syncWindowSize()
            ready = translator.isReadyFor(language)
            if (qwenMode && !ready) {
                val backend = translator as? QwenTranslationBackend
                val details = backend?.statusMessage ?: "AI 엔진 준비 중"
                updateQwenStatus(if (details.startsWith("오류:")) "AI 오류" else "AI 로딩", details)
            }
            // While on-device Qwen occupies CPU, don't launch another OCR job every 500 ms.
            // Keep the captured OCR coordinates stable until this translation finishes.
            if (qwenMode && activeTranslation != null) {
                handler.postDelayed(this, 500)
                return
            }
            val now = android.os.SystemClock.elapsedRealtime()
            if (translationEnabled && ready && !busy && chooser == null && regions.isNotEmpty() && now - lastOcrStarted >= 500L) {
                lastOcrStarted = now
                scan()
            }
            handler.postDelayed(this, 200)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        translator = MlKitTranslationBackend(applicationContext)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        dpi = resources.displayMetrics.densityDpi
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null) return START_NOT_STICKY
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val channel = "game_translator"
        nm.createNotificationChannel(NotificationChannel(channel, "게임 화면 번역", NotificationManager.IMPORTANCE_LOW))
        val notification = Notification.Builder(this, channel)
            .setContentTitle("GameTranslator 작동 중")
            .setContentText("화면 가장자리의 버튼으로 조작")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, notification)

        language = intent?.getIntExtra("language", 0) ?: 0
        val selectedEngine = intent?.getIntExtra("engine", 0) ?: 0
        qwenMode = selectedEngine == 1
        hybridMode = selectedEngine == 2
        if (hybridMode) {
            aiSession++
            aiTranslator = QwenTranslationBackend(applicationContext)
        }
        if (qwenMode) {
            translator.close()
            translator = QwenTranslationBackend(applicationContext)
        }
        val lang = language
        recognizer = if (lang == 0) TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                     else TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        ready = translator.isReadyFor(language)

        @Suppress("DEPRECATION")
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("resultData", Intent::class.java)
        else intent?.getParcelableExtra("resultData")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(intent?.getIntExtra("resultCode", Activity.RESULT_OK) ?: Activity.RESULT_OK, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { handler.post { stopSelf() } }
            override fun onCapturedContentResize(width: Int, height: Int) {
                handler.post {
                    // Follow the projection-provided buffer dimensions; mapping from
                    // capture pixels to overlay display pixels happens at OCR render time.
                    resizeCapture(width, height)
                }
            }
        }, handler)
        syncWindowSize()
        // v51: A fresh capture session starts with full-screen translation enabled.
        // Without an initial region, tick() skips OCR altogether and no overlay appears.
        if (regions.isEmpty()) {
            regions.add(RectF(0f, 0f, overlayWidth.toFloat(), overlayHeight.toFloat()))
        }
        resizeCapture(overlayWidth, overlayHeight, first = true)
        showBubble()
        if (qwenMode) updateQwenStatus("AI 로딩", "GGUF 모델 로딩을 시작했습니다")
        toast("전체 화면 번역 활성화 · 필요하면 영역 선택에서 변경")
        handler.postDelayed(tick, 1800)
        return START_NOT_STICKY
    }

    // WindowManager.currentWindowMetrics describes the service's *window*, which may
    // have stale/letterboxed bounds on foldables. Overlay windows use display-space
    // coordinates, so query the physical display instead of activity window metrics.
    @Suppress("DEPRECATION")
    private fun windowBounds(): Rect {
        val displayManager = getSystemService(DISPLAY_SERVICE) as DisplayManager
        val display = displayManager.getDisplay(android.view.Display.DEFAULT_DISPLAY)
        if (display != null) {
            val point = Point()
            display.getRealSize(point)
            if (point.x > 0 && point.y > 0) return Rect(0, 0, point.x, point.y)
        }
        return if (Build.VERSION.SDK_INT >= 30) wm.maximumWindowMetrics.bounds
        else {
            val point = Point()
            wm.defaultDisplay.getRealSize(point)
            Rect(0, 0, point.x, point.y)
        }
    }

    private fun syncWindowSize() {
        val bounds = windowBounds()
        val w = bounds.width().coerceAtLeast(1)
        val h = bounds.height().coerceAtLeast(1)
        if (w == overlayWidth && h == overlayHeight) return
        val oldW = overlayWidth
        val oldH = overlayHeight
        if (oldW > 0 && oldH > 0) {
            regions.forEach { r ->
                r.set(r.left * w / oldW, r.top * h / oldH, r.right * w / oldW, r.bottom * h / oldH)
            }
            bubbleX = (bubbleX.toFloat() * w / oldW).roundToInt()
            bubbleY = (bubbleY.toFloat() * h / oldH).roundToInt()
        }
        overlayWidth = w; overlayHeight = h
        generation++
        clearLabels()
        if (chooser != null) {
            // Recreate the full-window selector after folding, rotation or split-screen resize.
            removeSafely(chooser); chooser = null
            selectRegions()
        }
        if (bubble != null) moveBubble(snap = true)
        if (menu != null) { removeSafely(menu); menu = null; expanded = false }
    }

    private fun resizeCapture(w: Int, h: Int, first: Boolean = false) {
        if (w <= 0 || h <= 0 || (w == captureWidth && h == captureHeight && !first)) return
        captureWidth = w; captureHeight = h
        val old = reader
        val next = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = next
        if (first) {
            virtualDisplay = projection?.createVirtualDisplay("GameTranslator", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, next.surface, null, handler)
        } else {
            virtualDisplay?.setSurface(null)
            virtualDisplay?.resize(w, h, dpi)
            virtualDisplay?.setSurface(next.surface)
        }
        old?.close()
        generation++
        clearLabels()
    }

    private fun params(w: Int, h: Int, touch: Boolean = true): WindowManager.LayoutParams {
        val flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            (if (touch) WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE else
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        return WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.LEFT }
    }

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).roundToInt()

    private fun showBubble() {
        val button = TextView(this).apply {
            text = "文A"; textSize = 17f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.rgb(28, 108, 215)); setStroke(dp(2), Color.CYAN)
            }
        }
        val p = params(dp(56), dp(56))
        p.x = bubbleX; p.y = bubbleY
        wm.addView(button, p); bubble = button
        var downX = 0f; var downY = 0f
        var startX = 0; var startY = 0; var dragged = false
        button.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = bubbleX; startY = bubbleY; dragged = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(event.rawX - downX) > dp(6) || abs(event.rawY - downY) > dp(6)) dragged = true
                    if (dragged) {
                        bubbleX = startX + (event.rawX - downX).roundToInt()
                        bubbleY = startY + (event.rawY - downY).roundToInt()
                        moveBubble(false)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (dragged) moveBubble(true) else toggleMenu()
                    true
                }
                else -> true
            }
        }
    }

    private fun moveBubble(snap: Boolean) {
        val v = bubble ?: return
        val size = dp(56)
        bubbleX = bubbleX.coerceIn(0, (overlayWidth - size).coerceAtLeast(0))
        bubbleY = bubbleY.coerceIn(0, (overlayHeight - size).coerceAtLeast(0))
        if (snap) bubbleX = if (bubbleX + size / 2 < overlayWidth / 2) 0 else (overlayWidth - size).coerceAtLeast(0)
        try { wm.updateViewLayout(v, (v.layoutParams as WindowManager.LayoutParams).apply { x = bubbleX; y = bubbleY }) } catch (_: Exception) {}
        if (menu != null) { removeSafely(menu); menu = null; expanded = false }
    }

    private fun toggleMenu() {
        if (expanded) { removeSafely(menu); menu = null; expanded = false; return }
        val bar = LinearLayout(this).apply {
            orientation = if (overlayWidth < dp(360)) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            setPadding(dp(3), dp(3), dp(3), dp(3))
            setBackgroundColor(Color.argb(235, 23, 34, 52))
        }
        fun addButton(text: String, action: () -> Unit) {
            bar.addView(Button(this).apply { this.text = text; textSize = 12f; setOnClickListener { toggleMenu(); action() } })
        }
        if (qwenMode) {
            bar.addView(TextView(this).apply {
                text = "AI 진단: $lastDiagnostics"
                textSize = 12f
                setTextColor(Color.WHITE)
                setPadding(dp(8), dp(8), dp(8), dp(8))
            })
        }
        if (qwenMode) addButton("표시 시험") {
            // Independent of OCR and AI. Confirms TYPE_APPLICATION_OVERLAY text rendering.
            val probe = TextView(this).apply {
                text = "오버레이 표시 정상 (AI와 무관)"
                textSize = 18f
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.rgb(0, 90, 60))
                setPadding(dp(12), dp(10), dp(12), dp(10))
            }
            val lp = params(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, false)
            lp.x = dp(14); lp.y = (overlayHeight / 3).coerceAtLeast(dp(70))
            try {
                wm.addView(probe, lp)
                updateQwenStatus("표시 시험", "초록색 진단 문구 표시 중. 이것이 보이면 오버레이 출력은 정상")
                handler.postDelayed({ removeSafely(probe) }, 6000L)
            } catch (e: Exception) {
                updateQwenStatus("표시 오류", "오버레이 생성 실패: ${e.message}")
            }
        }
        addButton(if (translationEnabled) "번역 OFF" else "번역 ON") {
            translationEnabled = !translationEnabled
            generation++
            // OFF removes every secure translation window immediately. The floating
            // control stays non-secure, allowing normal screenshots while OFF.
            clearLabels()
            toast(if (translationEnabled) "번역 ON" else "번역 OFF")
        }
        addButton(if (language == 0) "언어: 영어" else "언어: 일본어") { switchLanguage() }
        addButton("영역 선택") { selectRegions() }
        addButton("초기화") { regions.clear(); clearLabels(); toast("영역 초기화") }
        addButton("종료") { stopSelf() }
        val p = params(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
        val right = bubbleX < overlayWidth / 2
        // Put menu beneath bubble so it remains accessible in narrow split windows.
        p.x = if (right) 0 else max(0, overlayWidth - dp(320))
        p.y = (bubbleY + dp(60)).coerceAtMost(max(0, overlayHeight - dp(180)))
        wm.addView(bar, p); menu = bar; expanded = true
    }

    private fun switchLanguage() {
        language = 1 - language
        generation++
        busy = false
        ready = false
        clearLabels()
        recognizer?.close()
        recognizer = if (language == 0) TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            else TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        ready = translator.isReadyFor(language)
        toast(if (language == 0) "영어 번역" else "일본어 번역")
    }

    private fun selectRegions() {
        clearLabels()
        val selection = SelectionView(this, regions) { finish ->
            removeSafely(chooser); chooser = null
            if (finish) toast("${regions.size}개 영역 자동 번역 시작")
        }
        chooser = selection
        // Explicit display dimensions avoid MATCH_PARENT inheriting stale portrait
        // window metrics on a foldable's expanded landscape display.
        wm.addView(selection, params(overlayWidth, overlayHeight))
    }

    private fun clearLabels() {
        labels.toList().forEach { removeSafely(it) }
        labels.clear()
        labelKeys.clear()
        missedScans.clear()
        labelBounds.clear()
        labelSource.clear()
        labelLastSeen.clear()
        candidateSource.clear()
        candidateHits.clear()
        lastSeenBounds.clear()
        scanSerial++
        latestSnapshot = ""
        // In-flight native work is allowed to finish, but its stale result is ignored.
        failedUntil.clear()
    }
    private fun removeSafely(view: View?) { if (view != null) try { wm.removeView(view) } catch (_: Exception) {} }

    // Hide previous translations before grabbing a new frame, so OCR cannot
    // mistake our own Korean overlay for the game's source text.
    private fun scan() {
        if (busy) return
        busy = true
        // Translation windows use FLAG_SECURE, so do not hide them on each scan.
        // Keep visible text stable while acquiring and processing the next frame.
        val gen = generation
        val scanId = ++scanSerial
        handler.postDelayed({
            if (gen != generation || chooser != null || !translationEnabled) {
                busy = false; return@postDelayed
            }
            val source = reader ?: run { busy = false; return@postDelayed }
            val image = try { source.acquireLatestImage() } catch (_: Exception) { null }
                ?: run { busy = false; return@postDelayed }
            try {
                val plane = image.planes[0]
                val paddedWidth = plane.rowStride / plane.pixelStride
                val bitmap = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
                bitmap.copyPixelsFromBuffer(plane.buffer)
                val cropped = Bitmap.createBitmap(bitmap, 0, 0, image.width, image.height)
                image.close(); bitmap.recycle()
                val imageW = cropped.width; val imageH = cropped.height
                recognizer?.process(InputImage.fromBitmap(cropped, 0))?.addOnSuccessListener { result ->
                    cropped.recycle()
                    if (gen != generation || chooser != null || !translationEnabled) { busy = false; return@addOnSuccessListener }
                    val sx = overlayWidth.toFloat() / imageW
                    val sy = overlayHeight.toFloat() / imageH
                    // v44: OCR lines are not necessarily complete sentences. Group
                    // geometrically coherent dialogue/notice paragraphs before translation.
                    val tasks = groupParagraphs(result.textBlocks, sx, sy).take(30)
                    if (qwenMode && activeTranslation == null) {
                        updateQwenStatus(if (tasks.isEmpty()) "OCR 0" else "OCR ${tasks.size}",
                            "OCR 인식 완료: ${tasks.size}개 문단, 읽기 준비=${translator.isReadyFor(language)}")
                    }
                    val seen = mutableSetOf<String>()
                    // Match OCR lines to already visible labels by actual position, not
                    // just a coarse grid key. Small OCR jitter must not create duplicates.
                    val claimed = mutableSetOf<String>()
                    if (tasks.isEmpty()) {
                        // Empty game text: remove translations on this very scan.
                        latestSnapshot = ""
                        ageLabels(seen, scanId)
                        busy = false
                        return@addOnSuccessListener
                    }
                    data class Pending(val key: String, val source: String, val rect: Rect, val region: RectF)
                    val pending = mutableListOf<Pending>()
                    tasks.forEach { (text, rect, region) ->
                        val target = Rect(
                            (rect.left * sx).roundToInt(), (rect.top * sy).roundToInt(),
                            (rect.right * sx).roundToInt(), (rect.bottom * sy).roundToInt())
                        val key = findExistingLabel(target, claimed) ?: labelKey(rect, imageW, imageH)
                        claimed.add(key)
                        seen.add(key)
                        val oldText = labelSource[key]
                        val stableText = if (oldText != null && oldText != text) {
                            // Wait for two consecutive matching OCR observations before
                            // accepting a changed sentence at the same screen location.
                            if (candidateSource[key] == text) candidateHits[key] = (candidateHits[key] ?: 0) + 1
                            else { candidateSource[key] = text; candidateHits[key] = 1 }
                            if ((candidateHits[key] ?: 0) >= 2) {
                                candidateSource.remove(key); candidateHits.remove(key)
                                labelSource[key] = text
                                text
                            } else oldText
                        } else {
                            candidateSource.remove(key); candidateHits.remove(key)
                            labelSource[key] = text
                            text
                        }
                        labelLastSeen[key] = scanId
                        lastSeenBounds[key] = target
                        pending.add(Pending(key, stableText, rect, region))
                    }
                    // A snapshot includes all recognized lines and their positions. A late result
                    // must never overwrite a newer game screen.
                    val snapshot = pending.joinToString("\u001e") { "${it.key}\u001f${it.source}" }
                    latestSnapshot = snapshot
                    val uncached = pending.map { it.source }.distinct().filter {
                        translationCache["$language|$it"] == null &&
                            (failedUntil["$language|$it"] ?: 0L) <= android.os.SystemClock.elapsedRealtime()
                    }
                    val commit: () -> Unit = {
                        if (gen == generation && latestSnapshot == snapshot && translationEnabled && chooser == null &&
                            pending.all { labelSource[it.key] == it.source && translationCache["$language|${it.source}"] != null }) {
                            // All translations are ready before any new label is displayed.
                            pending.forEach { item ->
                                showLineLabel(item.key, (if (hybridMode) aiCache["$language|${item.source}"] else null) ?: translationCache["$language|${item.source}"]!!,
                                    item.rect, item.region, imageW, imageH)
                            }
                        }
                    }
                    if (hybridMode) {
                        // Fast ML Kit is authoritative until a matching AI result arrives.
                        // OCR refresh and ML Kit never wait for native inference.
                        pending.forEach { item ->
                            val key = "$language|${item.source}"
                            val value = aiCache[key] ?: translationCache[key]
                            if (!value.isNullOrBlank() && labelSource[item.key] == item.source) {
                                showLineLabel(item.key, value, item.rect, item.region, imageW, imageH)
                            }
                        }
                        startAiIfNeeded(pending.map { it.key to it.source })
                        if (uncached.isNotEmpty() && activeTranslation == null) {
                            activeTranslation = snapshot
                            translator.translateBatch(uncached, language) { translated, error -> handler.post {
                                translated.forEachIndexed { index, value ->
                                    val key = "$language|${uncached[index]}"
                                    if (value.isNotBlank()) translationCache[key] = value
                                    else failedUntil[key] = android.os.SystemClock.elapsedRealtime() + 30000L
                                }
                                if (error != null) android.util.Log.w("GameTranslator", error)
                                if (activeTranslation == snapshot) activeTranslation = null
                                if (gen == generation && translationEnabled && chooser == null) {
                                    // Never downgrade an already upgraded AI translation.
                                    pending.forEach { item ->
                                        if (labelSource[item.key] != item.source) return@forEach
                                        val key = "$language|${item.source}"
                                        val value = aiCache[key] ?: translationCache[key]
                                        if (!value.isNullOrBlank()) showLineLabel(item.key, value, item.rect, item.region, imageW, imageH)
                                    }
                                }
                            } }
                        }
                    } else if (qwenMode) {
                        // A local LLM may need seconds per sentence. Never wait for all OCR
                        // items or a byte-identical screen snapshot before showing results.
                        pending.forEach { item ->
                            val value = translationCache["$language|${item.source}"]
                            if (!value.isNullOrBlank() && labelSource[item.key] == item.source) {
                                showLineLabel(item.key, value, item.rect, item.region, imageW, imageH)
                            }
                        }
                        if (uncached.isNotEmpty() && activeTranslation == null) {
                            val sourceText = uncached.first()
                            activeTranslation = sourceText
                            val startedAt = android.os.SystemClock.elapsedRealtime()
                            updateQwenStatus("AI 번역", "AI 추론 시작: ${sourceText.take(60)}")
                            handler.postDelayed({
                                if (activeTranslation == sourceText && qwenMode) {
                                    val elapsed = (android.os.SystemClock.elapsedRealtime() - startedAt) / 1000
                                    updateQwenStatus("AI 대기", "추론 진행 중 ${elapsed}초: ${sourceText.take(45)}")
                                }
                            }, 12000L)
                            translator.translate(sourceText, language) { resultText, error -> handler.post {
                                if (resultText.isNotBlank()) {
                                    updateQwenStatus("AI 완료", "${(android.os.SystemClock.elapsedRealtime()-startedAt)/1000}초, 결과: ${resultText.take(100)}")
                                    translationCache["$language|$sourceText"] = resultText
                                    // Display at the latest recognized location even when OCR
                                    // boxes shifted while the AI was generating text.
                                    pending.filter { it.source == sourceText && labelSource[it.key] == sourceText }
                                        .forEach { item ->
                                            if (gen == generation && translationEnabled && chooser == null) {
                                                showLineLabel(item.key, resultText, item.rect, item.region, imageW, imageH)
                                            }
                                        }
                                } else {
                                    failedUntil["$language|$sourceText"] = android.os.SystemClock.elapsedRealtime() + 15000L
                                    updateQwenStatus("AI 오류", "${(android.os.SystemClock.elapsedRealtime()-startedAt)/1000}초, 오류: ${error ?: "빈 응답"}")
                                    android.util.Log.w("GameTranslator", "Qwen empty result: ${error ?: "no details"}")
                                }
                                activeTranslation = null
                            } }
                        }
                    } else if (uncached.isEmpty()) {
                        commit()
                    } else if (activeTranslation == null) {
                        activeTranslation = snapshot
                        translator.translateBatch(uncached, language) { translated, error -> handler.post {
                            translated.forEachIndexed { index, value ->
                                val key = "$language|${uncached[index]}"
                                if (value.isNotBlank()) translationCache[key] = value
                                else failedUntil[key] = android.os.SystemClock.elapsedRealtime() + 30000L
                            }
                            if (error != null) android.util.Log.w("GameTranslator", error)
                            if (activeTranslation == snapshot) activeTranslation = null
                            commit()
                        } }
                    }
                    ageLabels(seen, scanId)
                    busy = false
                }?.addOnFailureListener { cropped.recycle(); busy = false }
            } catch (_: Exception) {
                try { image.close() } catch (_: Exception) {}
                busy = false
            }
        }, 80)
    }

    /** Groups OCR lines into translation units without collapsing menus into one sentence.
     * ML Kit block identity is a useful hint, not a mandatory paragraph boundary.
     * All geometry here is in capture pixels; region membership uses overlay pixels.
     */
    private fun groupParagraphs(
        blocks: List<com.google.mlkit.vision.text.Text.TextBlock>, sx: Float, sy: Float
    ): List<Triple<String, Rect, RectF>> {
        data class LineInfo(val text: String, val box: Rect, val regionIndex: Int, val blockIndex: Int)
        val lines = mutableListOf<LineInfo>()
        blocks.forEachIndexed { blockIndex, block ->
            block.lines.forEach { line ->
                val r = line.boundingBox ?: return@forEach
                val value = line.text.trim()
                if (value.isBlank() || !value.any { it.isLetter() }) return@forEach
                val cx = r.exactCenterX() * sx
                val cy = r.exactCenterY() * sy
                val regionIndex = regions.indexOfFirst { it.contains(cx, cy) }
                if (regionIndex >= 0) lines.add(LineInfo(value, Rect(r), regionIndex, blockIndex))
            }
        }
        if (lines.isEmpty()) return emptyList()
        // Preserve reading order within each selected region.
        val ordered = lines.sortedWith(compareBy<LineInfo> { it.regionIndex }.thenBy { it.box.top }.thenBy { it.box.left })
        data class Group(val items: MutableList<LineInfo>, var bounds: Rect)
        val groups = mutableListOf<Group>()
        for (line in ordered) {
            val last = groups.lastOrNull()
            val prev = last?.items?.lastOrNull()
            var join = false
            if (prev != null && prev.regionIndex == line.regionIndex) {
                val a = prev.box; val b = line.box
                val h = max(1, max(a.height(), b.height()))
                val gap = b.top - a.bottom
                val leftDelta = abs(a.left - b.left)
                val rightDelta = abs(a.right - b.right)
                val overlap = max(0, min(a.right, b.right) - max(a.left, b.left))
                val aligned = leftDelta <= h * 1.6f || rightDelta <= h * 1.6f
                val close = gap >= -h * 0.25f && gap <= h * 1.45f
                val sameColumn = overlap > min(a.width(), b.width()) * 0.28f || aligned
                val previousEnd = prev.text.trimEnd()
                val nextStart = line.text.trimStart()
                val previousFinished = previousEnd.endsWith('.') || previousEnd.endsWith('!') ||
                    previousEnd.endsWith('?') || previousEnd.endsWith(':') || previousEnd.endsWith('。')
                // Wrapping can leave a single word ("you.") on the next line.
                // Strong continuation signals override ML Kit block boundaries.
                val startsContinuation = nextStart.firstOrNull()?.isLowerCase() == true ||
                    nextStart.startsWith("*") || nextStart.startsWith("…") || nextStart.startsWith("...")
                val previousLong = prev.text.length >= 34
                val firstLineUnfinished = !previousFinished || previousEnd.endsWith("...") ||
                    previousEnd.endsWith("…")
                val shortOptions = prev.text.length <= 26 && line.text.length <= 26 &&
                    prev.text.split(Regex("\\s+")).size <= 4 && line.text.split(Regex("\\s+")).size <= 4 &&
                    !startsContinuation && !previousLong &&
                    prev.text.firstOrNull()?.isUpperCase() == true &&
                    line.text.firstOrNull()?.isUpperCase() == true
                // Keep independent menu rows separate, but accept generous dialogue line spacing.
                // A short last line is expected when a sentence wraps near the box edge.
                val looksWrapped = previousLong && (firstLineUnfinished || startsContinuation)
                val alignedStrongly = leftDelta <= h * 1.4f
                val generousGap = gap >= -h * 0.3f && gap <= h * 2.6f
                val sameBlock = prev.blockIndex == line.blockIndex
                val likelyContinuation = looksWrapped || (sameBlock && firstLineUnfinished) ||
                    (startsContinuation && firstLineUnfinished)
                join = generousGap && sameColumn && alignedStrongly && !shortOptions && likelyContinuation
                // Do not merge unrelated lines separated by a large blank panel.
                if (gap > h * 2.6f) join = false
            }
            if (join && last != null) {
                last.items.add(line)
                last.bounds.union(line.box)
            } else groups.add(Group(mutableListOf(line), Rect(line.box)))
        }
        return groups.map { group ->
            val text = group.items.joinToString(" ") { it.text.trim() }
                .replace(Regex("\\s+"), " ").trim()
            Triple(text, group.bounds, RectF(regions[group.items.first().regionIndex]))
        }
    }

    private fun labelKey(rect: Rect, imageW: Int, imageH: Int): String {
        val x = (rect.left.toFloat() * overlayWidth / imageW / dp(24)).roundToInt()
        val y = (rect.top.toFloat() * overlayHeight / imageH / dp(18)).roundToInt()
        return "$x:$y"
    }

    private fun ageLabels(seen: Set<String>, scanId: Int) {
        // Pending translations also need to expire when their source disappears.
        for (key in labelSource.keys.toList()) {
            if (key !in seen && key !in labelKeys) {
                labelSource.remove(key)
                labelLastSeen.remove(key)
                candidateSource.remove(key)
                candidateHits.remove(key)
                lastSeenBounds.remove(key)
            }
        }
        for (key in labelKeys.keys.toList()) {
            if (key in seen) { missedScans[key] = 0; continue }
            val misses = (missedScans[key] ?: 0) + 1
            if (misses >= 2) {
                val view = labelKeys.remove(key)
                if (view != null) {
                    removeSafely(view)
                    labels.remove(view)
                }
                missedScans.remove(key)
                labelBounds.remove(key)
                labelSource.remove(key)
                labelLastSeen.remove(key)
                candidateSource.remove(key)
                candidateHits.remove(key)
                lastSeenBounds.remove(key)
            } else missedScans[key] = misses
        }
    }

    private fun findExistingLabel(target: Rect, claimed: Set<String>): String? {
        val toleranceX = dp(35)
        val toleranceY = dp(18)
        return labelBounds.entries.asSequence()
            .filter { it.key !in claimed }
            .map { entry ->
                val b = entry.value
                val dx = kotlin.math.abs(b.left - target.left)
                val dy = kotlin.math.abs(b.top - target.top)
                Triple(entry.key, dx, dy)
            }
            .filter { it.second <= toleranceX && it.third <= toleranceY }
            .minByOrNull { it.second + it.third * 2 }?.first
    }

    private fun showLineLabel(key: String, value: String, rect: Rect, region: RectF, imageW: Int, imageH: Int) {
        if (overlayWidth <= 0 || overlayHeight <= 0) return
        val sx = overlayWidth.toFloat() / imageW
        val sy = overlayHeight.toFloat() / imageH
        val left = (rect.left * sx).roundToInt().coerceAtLeast(region.left.roundToInt()).coerceAtLeast(0)
        val top = (rect.top * sy).roundToInt().coerceAtLeast(region.top.roundToInt()).coerceAtLeast(0)
        val right = region.right.roundToInt().coerceAtMost(overlayWidth)
        val bottom = region.bottom.roundToInt().coerceAtMost(overlayHeight)
        if (right <= left || bottom <= top) return
        // Each OCR line gets its own anchored label, not a giant region-wide box.
        val originalWidth = max(dp(36), (rect.width() * sx).roundToInt())
        val maxWidth = right - left
        val preferred = max(originalWidth, if (rect.height() * sy > dp(28)) dp(230) else dp(110)).coerceAtMost(maxWidth)
        val pad = dp(2)
        val label = TextView(this).apply {
            text = value
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(18, 23, 32))
            setPadding(pad, 0, pad, 0)
            includeFontPadding = false
            gravity = Gravity.TOP or Gravity.START
            breakStrategy = android.text.Layout.BREAK_STRATEGY_HIGH_QUALITY
        }
        val maxHeight = bottom - top
        val widthSpec = View.MeasureSpec.makeMeasureSpec(preferred, View.MeasureSpec.EXACTLY)
        val heightSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        // Prefer legibility, but avoid covering other menu items when text is long.
        val originalHeight = max(dp(14), (rect.height() * sy).roundToInt())
        // A paragraph can occupy several original lines. Give its translation
        // room to wrap rather than squeezing it into a single-line height.
        val paragraph = value.length > 65 || originalHeight > dp(32)
        val budget = min(maxHeight, max(originalHeight * if (paragraph) 3 else 2, if (paragraph) dp(76) else dp(34)))
        for (fontSize in listOf(15f, 14f, 13f, 12f, 11f, 10f, 9f, 8f)) {
            label.textSize = fontSize
            label.measure(widthSpec, heightSpec)
            if (label.measuredHeight <= budget) break
        }
        val height = label.measuredHeight.coerceAtLeast(dp(12)).coerceAtMost(budget)
        val p = params(preferred, height, false)
        // Keep translated text visible to the user while excluding it from
        // MediaProjection capture. Prevents OCR feedback and periodic blinking.
        p.flags = p.flags or WindowManager.LayoutParams.FLAG_SECURE
        p.x = left; p.y = top
        // Remove old OCR labels occupying this same line before inserting a new one.
        // Without this, a slight OCR bounding-box shift can leave stacked translations.
        val newBounds = Rect(left, top, left + preferred, top + height)
        for ((otherKey, oldBounds) in labelBounds.toMap()) {
            if (otherKey == key) continue
            val overlap = Rect.intersects(newBounds, oldBounds)
            val closeTop = kotlin.math.abs(oldBounds.top - top) <= dp(12)
            val horizontalOverlap = oldBounds.left < newBounds.right && oldBounds.right > newBounds.left
            if (overlap && closeTop && horizontalOverlap) {
                val old = labelKeys.remove(otherKey)
                removeSafely(old)
                if (old != null) labels.remove(old)
                missedScans.remove(otherKey)
                labelBounds.remove(otherKey)
                labelSource.remove(otherKey)
                labelLastSeen.remove(otherKey)
            }
        }
        val existing = labelKeys[key]
        if (existing != null) {
            val changed = existing.text.toString() != value
            if (changed) existing.text = value
            val newSizeSp = label.textSize / resources.displayMetrics.scaledDensity
            if (kotlin.math.abs(existing.textSize / resources.displayMetrics.scaledDensity - newSizeSp) > 0.2f) {
                existing.textSize = newSizeSp
            }
            val old = labelBounds[key]
            if (changed || old == null || old.left != newBounds.left || old.top != newBounds.top ||
                old.width() != newBounds.width() || old.height() != newBounds.height()) {
                try { wm.updateViewLayout(existing, p) } catch (_: Exception) {}
            }
        } else {
            try { wm.addView(label, p); labels.add(label); labelKeys[key] = label } catch (_: Exception) {}
        }
        missedScans[key] = 0
        labelBounds[key] = newBounds
    }

    private fun toast(message: String) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show() }
    override fun onConfigurationChanged(newConfig: Configuration) { super.onConfigurationChanged(newConfig); handler.post { syncWindowSize() } }
    override fun onDestroy() {
        handler.removeCallbacks(tick)
        clearLabels(); removeSafely(chooser); removeSafely(menu); removeSafely(bubble)
        virtualDisplay?.release(); reader?.close(); projection?.stop()
        aiSession++
        aiTranslator?.close()
        recognizer?.close(); translator.close()
        super.onDestroy()
    }
}

private class SelectionView(context: Context, private val regions: MutableList<RectF>,
                            private val finish: (Boolean) -> Unit) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var sx = 0f; private var sy = 0f; private var ex = 0f; private var ey = 0f
    private var drawing = false
    private var completionPressed = false
    private val density = resources.displayMetrics.density
    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.argb(80, 0, 0, 0))
        paint.color = Color.CYAN; paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f * density
        regions.forEach { canvas.drawRect(it, paint) }
        if (drawing) canvas.drawRect(sx, sy, ex, ey, paint)
        paint.style = Paint.Style.FILL; paint.color = Color.WHITE; paint.textSize = 16f * density
        canvas.drawText("드래그: 영역 추가", 12f * density, 88f * density, paint)
        paint.color = Color.rgb(35, 110, 210)
        canvas.drawRoundRect(8f * density, 8f * density, 116f * density, 60f * density, 12f * density, 12f * density, paint)
        paint.color = Color.WHITE; paint.textSize = 17f * density
        canvas.drawText("전체화면", 20f * density, 41f * density, paint)
        paint.color = Color.rgb(35, 110, 210)
        val buttonW = 86f * density; val buttonH = 52f * density
        canvas.drawRoundRect(width - buttonW - 8f * density, 8f * density,
            width - 8f * density, buttonH + 8f * density, 12f * density, 12f * density, paint)
        paint.color = Color.WHITE; paint.textSize = 20f * density
        canvas.drawText("완료", width - buttonW + 9f * density, 41f * density, paint)
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                completionPressed = inDoneButton(event.x, event.y)
                if (completionPressed) return true
                if (inFullButton(event.x, event.y)) {
                    regions.clear()
                    regions.add(RectF(0f, 0f, width.toFloat(), height.toFloat()))
                    invalidate()
                    return true
                }
                sx = event.x; sy = event.y; ex = sx; ey = sy; drawing = true; invalidate(); return true
            }
            MotionEvent.ACTION_MOVE -> { if (drawing) { ex = event.x; ey = event.y; invalidate() }; return true }
            MotionEvent.ACTION_CANCEL -> { drawing = false; completionPressed = false; invalidate(); return true }
            MotionEvent.ACTION_UP -> {
                if (completionPressed) {
                    completionPressed = false
                    if (inDoneButton(event.x, event.y)) finish(true)
                    return true
                }
                if (drawing) {
                    ex = event.x; ey = event.y; drawing = false
                    val r = RectF(min(sx, ex), min(sy, ey), max(sx, ex), max(sy, ey))
                    if (r.width() > 25f * density && r.height() > 16f * density) regions.add(r)
                    invalidate()
                }
                return true
            }
        }
        return true
    }
    private fun inFullButton(x: Float, y: Float): Boolean =
        x >= 8f * density && x <= 116f * density &&
        y >= 8f * density && y <= 60f * density
    private fun inDoneButton(x: Float, y: Float): Boolean =
        x >= width - 94f * density && x <= width - 8f * density &&
        y >= 8f * density && y <= 60f * density
}
