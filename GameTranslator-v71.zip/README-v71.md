# v71 Android APK source

This version builds an Android APK using the existing ML Kit game overlay. The obsolete M2M100 test screen has been removed. OPUS-MT English/Japanese→Korean is **NOT implemented** in this version. This is an APK packaging correction, not an OPUS-MT release.
