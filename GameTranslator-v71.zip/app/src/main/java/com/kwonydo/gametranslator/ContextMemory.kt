package com.kwonydo.gametranslator

import android.content.Context
import org.json.JSONArray
import java.util.ArrayDeque

/** Bounded OCR history, separate from translation cache. No genre is hard-coded. */
class ContextMemory(context: Context) {
    private val prefs = context.getSharedPreferences("context_memory_v1", Context.MODE_PRIVATE)
    private val recent = ArrayDeque<String>()
    init {
        try {
            val saved = JSONArray(prefs.getString("history", "[]"))
            for (i in 0 until saved.length()) add(saved.optString(i), false)
        } catch (_: Exception) { }
    }
    @Synchronized fun add(text: String, persist: Boolean = true) {
        val normalized = text.replace(Regex("[\\r\\n]+"), " ").trim().take(180)
        if (normalized.length < 3 || recent.lastOrNull() == normalized) return
        recent.remove(normalized)
        recent.addLast(normalized)
        while (recent.size > 60) recent.removeFirst()
        if (persist) prefs.edit().putString("history", JSONArray(recent.toList()).toString()).apply()
    }
    @Synchronized fun addAll(texts: List<String>) {
        texts.take(16).forEach { add(it, false) }
        prefs.edit().putString("history", JSONArray(recent.toList()).toString()).apply()
    }
    @Synchronized fun contextFor(source: String): String = recent.asSequence()
        .filter { it != source }.takeLastCompat(12).joinToString(" | ").take(1000)
    @Synchronized fun clear() { recent.clear(); prefs.edit().remove("history").apply() }
    private fun <T> Sequence<T>.takeLastCompat(count: Int): List<T> = this.toList().takeLast(count)
}
