package com.kwonydo.gametranslator

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File
import java.util.concurrent.Executors

/** One background thread owns the LiteRT-LM engine and each short-lived conversation. */
class GemmaEngine(private val context: Context) {
    private val worker = Executors.newSingleThreadExecutor()
    private var engine: LlmInference? = null
    @Volatile private var closed = false

    fun initialize(done: (Boolean, String) -> Unit) {
        if (closed) { done(false, "엔진 종료됨"); return }
        worker.execute {
            var message = "MediaPipe Gemma .task 모델 준비 완료"
            val success = try {
                if (engine == null) {
                    val model = prepareBundledModel(context)
                    val options = LlmInference.LlmInferenceOptions.builder()
                        .setModelPath(model.absolutePath)
                        .setMaxTokens(1024)
                                                .build()
                    val candidate = LlmInference.createFromOptions(context, options)
                    engine = candidate
                }
                true
            } catch (e: Throwable) {
                Log.e("GameTranslatorGemma", "MediaPipe initialization", e)
                message = "초기화 실패: ${e.javaClass.simpleName}: ${e.message ?: "원인 미상"}"
                false
            }
            done(success, message)
        }
    }

    fun translate(text: String, language: Int, done: (String, String?, String) -> Unit, contextHint: String = "") {
        if (closed) { done("", "Gemma 엔진 종료됨", ""); return }
        worker.execute {
            var raw = ""
            var error: String? = null
            var translation = ""
            try {
                val model = engine ?: throw IllegalStateException("Gemma가 초기화되지 않았습니다")
                val source = if (language == 0) "English" else "Japanese"
                val input = text.replace(Regex("[\\r\\n]+"), " ").trim().take(1200)
                // MediaPipe .task inference; input is real user text.
                // Gemma instruction-tuned model: isolate user text from instructions.
                // Restore the concise v20-style instruction. Keep optional scene context separate.
                val scene = contextHint.trim().take(350)
                val prompt = buildString {
                    append("Translate this $source video game text into natural Korean. ")
                    append("Preserve all meaning, names and tone. Output ONLY the Korean translation, no explanation.\n")
                    if (scene.isNotEmpty()) append("Context (not for translation): $scene\n")
                    append("Original: ").append(input).append("\nKorean:")
                }
                raw = model.generateResponse(prompt)
                translation = normalize(raw, input)
                if (translation.isEmpty()) {
                    error = if (raw.isBlank()) "모델 응답 0자" else "한국어 번역 추출 실패"
                }
            } catch (e: Throwable) {
                Log.e("GameTranslatorGemma", "MediaPipe inference", e)
                error = "추론 실패: ${e.javaClass.simpleName}: ${e.message ?: "원인 미상"}"
            }
            done(translation, error, raw)
        }
    }

    fun correct(sourceText: String, mlTranslation: String, language: Int, done: (String, String?, String) -> Unit, contextHint: String = "") {
        if (closed) { done("", "Gemma 엔진 종료됨", ""); return }
        worker.execute {
            var raw = ""
            var result = ""
            var error: String? = null
            try {
                val model = engine ?: throw IllegalStateException("Gemma가 초기화되지 않았습니다")
                val sourceLanguage = if (language == 0) "English" else "Japanese"
                val original = sourceText.replace(Regex("[\r\n]+"), " ").trim().take(1200)
                val draft = mlTranslation.replace(Regex("[\r\n]+"), " ").trim().take(400)
                val scene = contextHint.trim().take(350)
                val prompt = buildString {
                    append("Improve this Korean game translation using the original $sourceLanguage text. ")
                    append("Keep every fact and action from the original. Do not invent or omit content. ")
                    append("Output ONLY the corrected natural Korean translation.\n")
                    if (scene.isNotEmpty()) append("Context (not for translation): $scene\n")
                    append("Original: ").append(original).append("\n")
                    append("Draft: ").append(draft).append("\nCorrected Korean:")
                }
                raw = model.generateResponse(prompt)
                result = normalize(raw, original)
                if (result.isBlank()) error = "한국어 교정 결과 추출 실패"
            } catch (e: Throwable) {
                Log.e("GameTranslatorGemma", "Correction inference", e)
                error = "교정 추론 실패: ${e.javaClass.simpleName}: ${e.message ?: "원인 미상"}"
            }
            done(result, error, raw)
        }
    }

    private fun normalize(raw: String, source: String): String {
        val cleaned = raw.substringBefore("<end_of_turn>")
            .replace(Regex("(?i)^\\s*(korean|translation|번역)\\s*[:：]\\s*"), "")
            .replace(Regex("[\\r\\n]+"), " ")
            .trim().trim('"', '\'')
        val normalized = cleaned.replace("\\n", " ").replace("\\r", " ").replace(Regex("\\s+"), " ").trim()
        if (normalized.isEmpty() || normalized.length > maxOf(100, source.length * 5)) return ""
        if (!normalized.any { it in '\uAC00'..'\uD7A3' }) return ""
        return normalized
    }

    fun close() {
        if (closed) return
        closed = true
        worker.execute {
            val old = engine
            engine = null
            if (old != null) try { old.close() } catch (e: Exception) {
                Log.w("GameTranslatorGemma", "Close failed", e)
            }
        }
        worker.shutdown()
    }

    companion object {
        private const val FILE_NAME = "Gemma3-1B-IT_multi-prefill-seq_q4_ekv2048.task"
        fun modelFile(context: Context): File = File(context.filesDir, FILE_NAME)

        private fun prepareBundledModel(context: Context): File {
            val target = modelFile(context)
            check(target.isFile && target.length() > 500_000_000L) { "Gemma 모델 파일을 먼저 다운로드하세요" }
            return target
        }
    }
}
