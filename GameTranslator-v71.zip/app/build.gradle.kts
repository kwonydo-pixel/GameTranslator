plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.kwonydo.gametranslator"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.kwonydo.gametranslator"
        minSdk = 28
        targetSdk = 35
        versionCode = 71
        versionName = "0.71"
    }
    defaultConfig { ndk { abiFilters += listOf("arm64-v8a") }; externalNativeBuild { cmake { cppFlags += listOf("-std=c++17") } } }
    externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }

}
kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}
dependencies {
    implementation("com.google.mediapipe:tasks-genai:0.10.27")
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:text-recognition-japanese:16.0.1")
}
