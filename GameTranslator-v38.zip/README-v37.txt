v37: Fix LiteRT-LM Kotlin Message response: sendMessage returns Message, which does not expose .text. Use .toString() as documented. Kotlin 2.3.20 retained. Build not verified.
