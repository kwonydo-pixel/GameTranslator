v34: Kotlin 1.9.25 K1 frontend diagnostic build to avoid Kotlin 2.1.20 FIR type-checker crash. Build not verified.
