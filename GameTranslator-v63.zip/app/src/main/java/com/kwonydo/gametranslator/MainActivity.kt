package com.kwonydo.gametranslator

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.view.Gravity
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val captureCode = 1001
    private var language = 0
    private var engine = 0
    private val downloadExecutor = Executors.newSingleThreadExecutor()
    private val modelFile get() = GemmaEngine.modelFile(this)
    private var modelDownloading = false
    private lateinit var modelInfo: TextView
    private lateinit var downloadModel: Button
    private lateinit var downloadProgress: ProgressBar
    private lateinit var downloadProgressText: TextView
    private lateinit var tryModel: Button
    private lateinit var translationInput: EditText
    private lateinit var translationOutput: TextView
    private var testBackend: GemmaEngine? = null
    private var gemmaInitialized = false
    private var translating = false
    private var mlBackend: MlKitTranslationBackend? = null
    private lateinit var compareMl: TextView
    private lateinit var compareGemma: TextView
    private lateinit var compareEdited: TextView

    private fun modelValid(): Boolean = modelFile.isFile && modelFile.length() > 500_000_000L

    private fun releaseAssetUrl(): String {
        val api = URL("https://api.github.com/repos/kwonydo-pixel/GameTranslator/releases?per_page=30")
        val connection = api.openConnection() as HttpURLConnection
        connection.connectTimeout = 20000
        connection.readTimeout = 20000
        connection.setRequestProperty("Accept", "application/vnd.github+json")
        connection.setRequestProperty("User-Agent", "GameTranslator-Android")
        try {
            if (connection.responseCode !in 200..299) error("GitHub Releases HTTP ${connection.responseCode}")
            val releases = org.json.JSONArray(connection.inputStream.bufferedReader().use { it.readText() })
            for (i in 0 until releases.length()) {
                val assets = releases.getJSONObject(i).optJSONArray("assets") ?: continue
                for (j in 0 until assets.length()) {
                    val asset = assets.getJSONObject(j)
                    val name = asset.optString("name")
                    if (name.endsWith(".task", true) && name.contains("Gemma", true))
                        return asset.getString("browser_download_url")
                }
            }
            error("Releases에서 Gemma .task 모델을 찾지 못했습니다")
        } finally { connection.disconnect() }
    }

    private fun refreshModelStatus(message: String? = null) {
        modelInfo.text = message ?: if (modelValid())
            "Gemma 모델 준비됨 (${modelFile.length() / 1_000_000} MB)"
        else "Gemma 모델 없음. 아래 버튼을 눌러 앱에서 다운로드하세요."
        downloadModel.isEnabled = !modelDownloading
        downloadModel.text = if (modelDownloading) "Gemma 다운로드 중..." else if (modelValid()) "Gemma 모델 다시 다운로드" else "Gemma 모델 다운로드"
        downloadProgress.visibility = if (modelDownloading) android.view.View.VISIBLE else android.view.View.GONE
        downloadProgressText.visibility = if (modelDownloading) android.view.View.VISIBLE else android.view.View.GONE
        tryModel.isEnabled = !modelDownloading && modelValid()
    }

    private fun downloadGemmaModel() {
        if (modelDownloading) return
        modelDownloading = true
        downloadProgress.progress = 0
        downloadProgressText.text = "연결 중..."
        refreshModelStatus("모델 다운로드 연결 중...")
        downloadExecutor.execute {
            val part = File(filesDir, "gemma.task.part")
            try {
                if (usableSpace() < 900_000_000L) throw Exception("저장 공간이 부족합니다 (900 MB 이상 필요)")
                val conn = URL(releaseAssetUrl()).openConnection() as HttpURLConnection
                conn.connectTimeout = 20000
                conn.readTimeout = 45000
                conn.instanceFollowRedirects = true
                conn.connect()
                if (conn.responseCode !in 200..299) throw Exception("다운로드 HTTP ${conn.responseCode}")
                val total = conn.contentLengthLong
                var done = 0L
                var lastUpdate = 0L
                conn.inputStream.use { input ->
                    FileOutputStream(part).use { output ->
                        val bytes = ByteArray(65536)
                        while (true) {
                            val n = input.read(bytes)
                            if (n == -1) break
                            output.write(bytes, 0, n)
                            done += n
                            val now = android.os.SystemClock.elapsedRealtime()
                            if (now - lastUpdate >= 400L) {
                                val label = if (total > 0) "모델 다운로드 ${done * 100 / total}% (${done / 1_000_000}/${total / 1_000_000} MB)"
                                            else "모델 다운로드 ${done / 1_000_000} MB"
                                val percent = if (total > 0) ((done * 100 / total).coerceIn(0, 100)).toInt() else 0
                                runOnUiThread {
                                    modelInfo.text = label
                                    downloadProgress.isIndeterminate = total <= 0
                                    if (total > 0) downloadProgress.progress = percent
                                    downloadProgressText.text = label
                                }
                                lastUpdate = now
                            }
                        }
                        output.fd.sync()
                    }
                }
                conn.disconnect()
                if (total > 0 && done != total) throw Exception("다운로드 용량 불일치")
                if (part.length() < 500_000_000L) throw Exception("모델 파일 크기가 예상보다 작습니다")
                if (modelFile.exists() && !modelFile.delete()) throw Exception("기존 모델 삭제 실패")
                if (!part.renameTo(modelFile)) throw Exception("모델 파일 이동 실패")
                runOnUiThread {
                    modelDownloading = false
                    refreshModelStatus("모델 다운로드 완료 (${modelFile.length() / 1_000_000} MB). 직접 번역기로 문장을 시험하세요.")
                }
            } catch (e: Exception) {
                part.delete()
                runOnUiThread {
                    modelDownloading = false
                    refreshModelStatus("다운로드 실패: ${e.message}. 다시 시도할 수 있습니다.")
                }
            }
        }
    }

    private fun usableSpace(): Long = filesDir.usableSpace

    private fun testGemma() {
        val source = translationInput.text.toString().trim()
        if (source.isBlank()) { translationOutput.text = "번역할 문장을 입력하세요."; return }
        if (translating) return
        translating = true
        tryModel.isEnabled = false
        compareMl.text = "① ML Kit: 준비 중..."
        compareGemma.text = "② Gemma 단독: 대기 중..."
        compareEdited.text = "③ ML Kit + Gemma 교정: 대기 중..."
        translationOutput.text = "실제 번역을 실행 중입니다."
        val started = android.os.SystemClock.elapsedRealtime()
        val ml = mlBackend ?: MlKitTranslationBackend(applicationContext).also { mlBackend = it }
        fun finish() { translating = false; tryModel.isEnabled = !modelDownloading }
        fun gemmaRun(mlResult: String?) {
            if (!modelValid()) {
                compareGemma.text = "② Gemma 단독: 모델을 먼저 다운로드하세요."
                compareEdited.text = "③ ML Kit + Gemma 교정: 모델 없음"
                finish(); return
            }
            val backend = testBackend ?: GemmaEngine(applicationContext).also { testBackend = it }
            fun perform() {
                val t1 = android.os.SystemClock.elapsedRealtime()
                backend.translate(source, language) { direct, directError, raw ->
                    runOnUiThread {
                        val elapsed = (android.os.SystemClock.elapsedRealtime() - t1) / 1000.0
                        compareGemma.text = if (directError == null) "② Gemma 단독 (${String.format(java.util.Locale.US, "%.1f", elapsed)}초):\n$direct" else "② Gemma 단독 실패: $directError\n원본: ${raw.take(250)}"
                    }
                    if (mlResult.isNullOrBlank()) {
                        runOnUiThread { compareEdited.text = "③ ML Kit + Gemma 교정: 초벌 번역이 없어 건너뜀"; finish() }
                    } else {
                        val t2 = android.os.SystemClock.elapsedRealtime()
                        backend.correct(source, mlResult, language) { corrected, correctionError, correctionRaw ->
                            runOnUiThread {
                                val seconds = (android.os.SystemClock.elapsedRealtime() - t2) / 1000.0
                                compareEdited.text = if (correctionError == null) "③ ML Kit + Gemma 교정 (${String.format(java.util.Locale.US, "%.1f", seconds)}초):\n$corrected" else "③ 교정 실패: $correctionError\n초벌 번역: $mlResult\n원본 응답: ${correctionRaw.take(200)}"
                                translationOutput.text = "3방식 비교 완료 (총 ${String.format(java.util.Locale.US, "%.1f", (android.os.SystemClock.elapsedRealtime()-started)/1000.0)}초)"
                                finish()
                            }
                        }
                    }
                }
            }
            if (gemmaInitialized) perform() else backend.initialize { success, message ->
                runOnUiThread { if (success) { gemmaInitialized = true; perform() } else { compareGemma.text = "② 초기화 실패: $message"; compareEdited.text = "③ 초기화 실패"; finish() } }
            }
        }
        fun mlRun(attempt: Int) {
            if (!ml.isReadyFor(language)) {
                if (attempt < 30) {
                    android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ mlRun(attempt + 1) }, 1000)
                } else {
                    compareMl.text = "① ML Kit: 언어 모델 준비 실패 (인터넷 연결 확인)"
                    gemmaRun(null)
                }
                return
            }
            val t = android.os.SystemClock.elapsedRealtime()
            ml.translate(source, language) { translated, error ->
                runOnUiThread {
                    val seconds = (android.os.SystemClock.elapsedRealtime() - t) / 1000.0
                    compareMl.text = if (error == null && translated.isNotBlank()) "① ML Kit (${String.format(java.util.Locale.US, "%.1f", seconds)}초):\n$translated" else "① ML Kit 실패: ${error ?: "빈 결과"}"
                    gemmaRun(if (error == null) translated else null)
                }
            }
        }
        mlRun(0)
    }

    override fun onDestroy() {
        mlBackend?.close()
        testBackend?.close()
        testBackend = null
        super.onDestroy()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val saved = getSharedPreferences("translator_settings", MODE_PRIVATE)
        language = saved.getInt("language", 0).coerceIn(0, 1)
        engine = saved.getInt("engine", 0).coerceIn(0, 2)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 32)
            setBackgroundColor(Color.rgb(20, 26, 40))
        }
        fun title(s: String) = TextView(this).apply { text=s; textSize=19f; setTextColor(Color.WHITE); setPadding(0,12,0,12) }
        root.addView(title("GameTranslator v63\n오프라인 게임 화면 번역"))
        fun readableAdapter(items: List<String>): ArrayAdapter<String> = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            override fun getView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                return super.getView(position, convertView, parent).also { (it as? TextView)?.setTextColor(Color.WHITE) }
            }
            override fun getDropDownView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                return super.getDropDownView(position, convertView, parent).also {
                    (it as? TextView)?.setTextColor(Color.BLACK)
                    it.setBackgroundColor(Color.WHITE)
                }
            }
        }.apply { setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        fun selectorBackground(): GradientDrawable = GradientDrawable().apply {
            setColor(Color.rgb(40, 53, 75))
            cornerRadius = 18f
            setStroke(3, Color.rgb(91, 153, 245))
        }
        fun selectionLabel(text: String) = TextView(this).apply {
            this.text = text; textSize = 15f; setTextColor(Color.rgb(186, 208, 237))
            setPadding(0, 22, 0, 9)
        }
        root.addView(selectionLabel("번역 언어 선택  ▾"))
        val spinner = Spinner(this).apply {
            background = selectorBackground()
            setPadding(24, 12, 24, 12)
            minimumHeight = 112
        }
        spinner.adapter = readableAdapter(listOf("영어 → 한국어", "일본어 → 한국어"))
        spinner.onItemSelectedListener = object: android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) { language=position; saved.edit().putInt("language", position).apply() }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        spinner.setSelection(language)
        root.addView(spinner)
        root.addView(selectionLabel("번역 엔진 선택"))
        val engineSpinner = Spinner(this).apply { background = selectorBackground(); setPadding(24, 12, 24, 12) }
        engineSpinner.adapter = readableAdapter(listOf("ML Kit (빠른 번역)", "Qwen 단독 (기존 기능)", "ML Kit + Qwen 보정 (기존 기능)"))
        engineSpinner.setSelection(engine)
        engineSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                engine = position; saved.edit().putInt("engine", position).apply()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        root.addView(engineSpinner)
        modelInfo = title("Gemma 모델 상태 확인 중...")
        root.addView(modelInfo)
        downloadModel = Button(this).apply { text = "Gemma 모델 다운로드" }
        downloadModel.setOnClickListener { downloadGemmaModel() }
        root.addView(downloadModel)
        downloadProgress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = android.view.View.GONE
        }
        root.addView(downloadProgress, LinearLayout.LayoutParams(-1, 20))
        downloadProgressText = TextView(this).apply {
            text = "0%"
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            visibility = android.view.View.GONE
        }
        root.addView(downloadProgressText)
        root.addView(selectionLabel("Gemma 직접 번역기 (영어/일본어 → 한국어)"))
        translationInput = EditText(this).apply {
            hint = "게임 대사나 원하는 문장을 직접 입력하세요"
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            textSize = 16f
            minLines = 2
            maxLines = 6
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            background = selectorBackground()
            setPadding(24, 20, 24, 20)
        }
        root.addView(translationInput)
        tryModel = Button(this).apply { text = "세 가지 방식으로 비교 번역" }
        tryModel.setOnClickListener { testGemma() }
        root.addView(tryModel)
        translationOutput = title("입력한 문장을 세 가지 엔진으로 비교합니다.")
        root.addView(translationOutput)
        compareMl = title("① ML Kit 초벌 번역: 대기 중")
        compareGemma = title("② Gemma 단독 번역: 대기 중")
        compareEdited = title("③ ML Kit + Gemma 교정: 대기 중")
        root.addView(compareMl)
        root.addView(compareGemma)
        root.addView(compareEdited)
        val chooseModel = Button(this).apply { text = "기존 Gemma .task 파일 가져오기 (선택)" }
        chooseModel.setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            }, 1002)
        }
        root.addView(chooseModel)
        refreshModelStatus()
        val status = title("Gemma 테스트는 Releases의 모델을 다운로드한 뒤 오프라인으로 실행됩니다.")
        val start = Button(this).apply { text="화면 번역 시작" }
        start.setOnClickListener {
            if (engine == 1 && !File(filesDir, "qwen.gguf").isFile) {
                Toast.makeText(this, "먼저 Gemma 모델을 다운로드하세요", Toast.LENGTH_LONG).show()
            } else if (engine == 1 && false) {
                Toast.makeText(this, "모델 다운로드가 끝난 뒤 시작하세요", Toast.LENGTH_LONG).show()
            } else if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "다른 앱 위에 표시 권한을 허용하고 돌아오세요", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), captureCode)
            }
        }
        root.addView(start)
        val stop = Button(this).apply { text="번역 종료" }
        stop.setOnClickListener { stopService(Intent(this, CaptureService::class.java)); status.text="번역 종료" }
        root.addView(stop)
        root.addView(status)
        root.addView(title("v63: 앱 내부 3방식 번역 비교 테스트"))
        root.addView(title("혼합 모드는 ML Kit을 즉시 표시하고, AI가 완료되면 같은 문장만 한 번 교체합니다.\n※ 첫 실행 시 모델 다운로드가 끝나야 번역이 시작됩니다."))
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(root) }
        setContentView(scroll)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1002 && resultCode == RESULT_OK && data?.data != null) {
            val uri = data.data!!
            Thread {
                try {
                    val file = modelFile
                    contentResolver.openInputStream(uri)!!.use { input -> file.outputStream().use { input.copyTo(it) } }
                    runOnUiThread { refreshModelStatus("Gemma 모델 저장 완료. 직접 번역기로 시험하세요.") }
                } catch (e: Exception) {
                    runOnUiThread { refreshModelStatus("모델 복사 실패: ${e.message}") }
                }
            }.start()
            return
        }
        if (requestCode==captureCode && resultCode==RESULT_OK && data!=null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("resultData", data)
                putExtra("language", language)
                putExtra("engine", engine)
            }
            if (Build.VERSION.SDK_INT>=26) startForegroundService(service) else startService(service)
            Toast.makeText(this, "번역 시작! 다른 앱으로 이동하세요.", Toast.LENGTH_LONG).show()
        }
    }
}
