package com.kwonydo.gametranslator

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

interface TranslationBackend {
    val isReady: Boolean
    fun isReadyFor(language: Int): Boolean
    fun translate(source: String, language: Int, done: (translation: String, error: String?) -> Unit)
    fun translateBatch(sources: List<String>, language: Int, done: (List<String>, String?) -> Unit)
    fun close()
}

/** ML Kit on-device translation. Models download once and are then used offline. */
class MlKitTranslationBackend(context: Context) : TranslationBackend {
    private val main = Handler(Looper.getMainLooper())
    private val translators: List<Translator> = listOf(TranslateLanguage.ENGLISH, TranslateLanguage.JAPANESE).map { source ->
        Translation.getClient(TranslatorOptions.Builder()
            .setSourceLanguage(source)
            .setTargetLanguage(TranslateLanguage.KOREAN)
            .build())
    }
    private val ready = BooleanArray(2)
    @Volatile private var closed = false
    override val isReady: Boolean get() = ready.any { it } && !closed
    override fun isReadyFor(language: Int): Boolean = language in 0..1 && ready[language] && !closed

    init {
        val conditions = DownloadConditions.Builder().build()
        translators.forEachIndexed { i, translator ->
            translator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener {
                    if (!closed) {
                        ready[i] = true
                        Log.i("GameTranslator", "ML Kit ${if (i == 0) "en" else "ja"}-ko model ready")
                    }
                }
                .addOnFailureListener { e ->
                    Log.e("GameTranslator", "ML Kit model download failed for language $i", e)
                }
        }
    }

    override fun translate(source: String, language: Int, done: (String, String?) -> Unit) {
        translateBatch(listOf(source), language) { results, error -> done(results.firstOrNull().orEmpty(), error) }
    }

    override fun translateBatch(sources: List<String>, language: Int, done: (List<String>, String?) -> Unit) {
        if (!isReadyFor(language)) {
            main.post { done(emptyList(), "ML Kit model not ready. Connect to internet for first download.") }
            return
        }
        if (sources.isEmpty()) {
            main.post { done(emptyList(), null) }
            return
        }
        val results = ArrayList<String>(sources.size)
        val translator = translators[language]
        fun next(index: Int) {
            if (closed) { done(emptyList(), "Translator closed"); return }
            if (index == sources.size) { done(results, null); return }
            translator.translate(sources[index])
                .addOnSuccessListener { value -> results.add(value); next(index + 1) }
                .addOnFailureListener { e ->
                    Log.w("GameTranslator", "ML Kit translation failed", e)
                    // Preserve index alignment, and allow the service to retry failed lines.
                    results.add("")
                    next(index + 1)
                }
        }
        main.post { next(0) }
    }

    override fun close() {
        closed = true
        ready.fill(false)
        translators.forEach { it.close() }
    }
}
