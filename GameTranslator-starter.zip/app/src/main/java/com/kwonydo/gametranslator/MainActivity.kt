package com.kwonydo.gametranslator

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import com.google.mlkit.nl.translate.*

class MainActivity : Activity() {
    private var translator: Translator? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.rgb(20, 26, 40))
        }
        val title = TextView(this).apply {
            text = "GameTranslator 0.1\n오프라인 번역 테스트"
            setTextColor(Color.WHITE)
            textSize = 22f
            gravity = Gravity.CENTER
        }
        val language = Spinner(this)
        language.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("영어 → 한국어", "일본어 → 한국어"))
        val input = EditText(this).apply {
            hint = "번역할 문장을 입력하세요"
            setText("Hello, adventurer!")
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
        }
        val status = TextView(this).apply {
            text = "언어를 선택하고 모델을 준비하세요."
            setTextColor(Color.WHITE)
            textSize = 17f
        }
        val button = Button(this).apply { text = "모델 준비 및 번역 테스트" }
        button.setOnClickListener {
            translator?.close()
            val source = if (language.selectedItemPosition == 0) TranslateLanguage.ENGLISH else TranslateLanguage.JAPANESE
            val current = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(source).setTargetLanguage(TranslateLanguage.KOREAN).build())
            translator = current
            status.text = "모델 준비 중... 최초 1회 다운로드가 필요합니다."
            current.downloadModelIfNeeded()
                .addOnSuccessListener {
                    current.translate(input.text.toString())
                        .addOnSuccessListener { result -> status.text = "번역 결과:\n$result" }
                        .addOnFailureListener { status.text = "번역 오류: ${it.message}" }
                }
                .addOnFailureListener { status.text = "모델 준비 오류: ${it.message}" }
        }
        root.addView(title)
        root.addView(language)
        root.addView(input)
        root.addView(button)
        root.addView(status)
        setContentView(root)
    }
    override fun onDestroy() {
        translator?.close()
        super.onDestroy()
    }
}
