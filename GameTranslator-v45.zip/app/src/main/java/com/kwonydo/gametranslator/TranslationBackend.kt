package com.kwonydo.gametranslator

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import io.github.marcosholgado.translatekit.ModelSpec
import io.github.marcosholgado.translatekit.TranslateKit
import io.github.marcosholgado.translatekit.TranslationModel
import java.io.File
import java.util.concurrent.Executors

interface TranslationBackend {
    val isReady: Boolean
    fun translate(source: String, language: Int, done: (translation: String, error: String?) -> Unit)
    fun translateBatch(sources: List<String>, language: Int, done: (List<String>, String?) -> Unit)
    fun close()
}

/** Real on-device Bergamot backend. English model is bundled as assets in this test build. */
class SlimtTranslationBackend(context: Context) : TranslationBackend {
    private val app = context.applicationContext
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var englishReady = false
    @Volatile private var initError = "Model is still loading"
    private var english: TranslationModel? = null
    @Volatile private var closed = false

    override val isReady: Boolean get() = englishReady

    init {
        worker.execute {
            try {
                val dir = File(app.filesDir, "bergamot/en-ko")
                dir.mkdirs()
                val names = listOf(
                    "model.enko.intgemm.alphas.bin",
                    "srcvocab.enko.spm",
                    "trgvocab.enko.spm",
                    "lex.50.50.enko.s2t.bin"
                )
                for (name in names) {
                    val dest = File(dir, name)
                    if (!dest.isFile || dest.length() == 0L) {
                        val temp = File(dir, "$name.tmp")
                        app.assets.open("en-ko/$name").use { input ->
                            temp.outputStream().use { output -> input.copyTo(output) }
                        }
                        if (!temp.renameTo(dest)) error("Cannot install model: $name")
                    }
                }
                TranslateKit.init(app)
                check(TranslateKit.isInitialized()) { "translate-kit native library unavailable" }
                english = TranslateKit.loadModel(ModelSpec(
                    sourceLang = "en", targetLang = "ko",
                    modelPath = File(dir, names[0]).absolutePath,
                    vocabPaths = listOf(File(dir, names[1]).absolutePath, File(dir, names[2]).absolutePath),
                    shortlistPath = File(dir, names[3]).absolutePath,
                    configYaml = null,
                    numWorkers = 1
                ))
                if (!closed) {
                    englishReady = true
                    val sample = english!!.translate("Hello, how are you?", false).text
                    Log.i("GameTranslator", "English model self-test: $sample")
                }
            } catch (t: Throwable) {
                initError = t.message ?: t.javaClass.simpleName
                Log.e("GameTranslator", "English model initialization failed", t)
            }
        }
    }

    override fun translate(source: String, language: Int, done: (String, String?) -> Unit) {
        if (language != 0) {
            main.post { done("", "Japanese model not installed yet") }
            return
        }
        worker.execute {
            val result = try {
                val model = english ?: error(initError)
                model.translate(source, false).text to null
            } catch (t: Throwable) {
                "" to (t.message ?: "Native translation failed")
            }
            main.post { done(result.first, result.second) }
        }
    }

    override fun translateBatch(sources: List<String>, language: Int, done: (List<String>, String?) -> Unit) {
        if (language != 0) {
            main.post { done(emptyList(), "Japanese model not installed yet") }
            return
        }
        worker.execute {
            val result = try {
                val model = english ?: error(initError)
                // Single native worker, one callback for the complete screen.
                model.translate(sources, false).map { it.text } to null
            } catch (t: Throwable) {
                emptyList<String>() to (t.message ?: "Native translation failed")
            }
            main.post { done(result.first, result.second) }
        }
    }

    override fun close() {
        closed = true
        englishReady = false
        worker.execute { english?.close(); english = null }
        worker.shutdown()
    }
}
