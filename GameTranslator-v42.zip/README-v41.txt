GameTranslator v41 - native slimt integration interface (INCOMPLETE)

Changes from v40:
- TranslationBackend now has a concrete SlimtTranslationBackend class with JNI entry points.
- Supports distinct en-ko and ja-ko model directories, single-threaded inference and callbacks.
- CaptureService initializes the new backend; OCR and overlay code are preserved.
- Version bumped to 41.

IMPORTANT: This is NOT a working slimt translation release. The libgametranslator_slimt.so
implementation and compatible translation models are NOT included. Without those, translation
will remain disabled. This archive is an integration milestone, not a finished translator.

Required next steps:
1. Cross-compile slimt and implement nativeOpen/nativeTranslate/nativeClose JNI functions.
2. Package arm64-v8a libgametranslator_slimt.so (and its native dependencies).
3. Obtain compatible Firefox/Bergamot models and map model filenames correctly.
4. Validate translation and memory/thermal behavior on device.

No cloud translation, fake results or external translator app is used.
