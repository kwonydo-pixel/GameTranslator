GameTranslator v42 SOURCE (NOT YET BUILD-VERIFIED)

Changes: replaces missing slimt JNI with real translate-kit Bergamot API; includes English model as assets during GitHub Actions build; checks ready state on each scan tick; English only.

To build: upload this ZIP to your GitHub repository as GameTranslator-v42.zip, then create the workflow v42.yml supplied separately (or see the workflow text in this archive). Trigger the workflow.

Model is downloaded at build time from midudev/firefox-translations. First app launch copies the model to private storage; may take time.

Japanese translation is NOT implemented. Native model compatibility and on-device translation remain UNVERIFIED until the APK runs.
