package com.kwonydo.gametranslator

import android.content.Context
import android.util.Log
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import java.io.File
import java.util.concurrent.Executors

/** One background thread owns the LiteRT-LM engine and each short-lived conversation. */
class GemmaEngine(private val context: Context) {
    private val worker = Executors.newSingleThreadExecutor()
    private var engine: Engine? = null
    @Volatile private var closed = false

    fun initialize(done: (Boolean, String) -> Unit) {
        if (closed) { done(false, "엔진 종료됨"); return }
        worker.execute {
            var message = "LiteRT-LM GPU 모델 준비 완료"
            val success = try {
                if (engine == null) {
                    val model = prepareBundledModel(context)
                    val candidate = Engine(EngineConfig(
                        modelPath = model.absolutePath,
                        backend = Backend.GPU(),
                        cacheDir = context.cacheDir.absolutePath
                    ))
                    // Never close an engine whose initialize() failed.
                    candidate.initialize()
                    engine = candidate
                }
                true
            } catch (e: Throwable) {
                Log.e("GameTranslatorGemma", "LiteRT-LM initialization", e)
                message = "초기화 실패: ${e.javaClass.simpleName}: ${e.message ?: "원인 미상"}"
                false
            }
            done(success, message)
        }
    }

    fun translate(text: String, language: Int, done: (String, String?, String) -> Unit) {
        if (closed) { done("", "Gemma 엔진 종료됨", ""); return }
        worker.execute {
            var raw = ""
            var error: String? = null
            var translation = ""
            try {
                val model = engine ?: throw IllegalStateException("Gemma가 초기화되지 않았습니다")
                val source = if (language == 0) "English" else "Japanese"
                val input = text.replace(Regex("[\\r\\n]+"), " ").trim().take(300)
                // LiteRT-LM handles chat templates. Do NOT inject Gemma turn tokens.
                val prompt = "Translate this video game dialogue from $source into natural Korean. " +
                    "Output only the Korean translation, without explanations or labels.\n\n$input"
                model.createConversation().use { conversation ->
                    raw = conversation.sendMessage(prompt).toString()
                }
                translation = normalize(raw, input)
                if (translation.isEmpty()) {
                    error = if (raw.isBlank()) "모델 응답 0자" else "한국어 번역 추출 실패"
                }
            } catch (e: Throwable) {
                Log.e("GameTranslatorGemma", "LiteRT-LM inference", e)
                error = "추론 실패: ${e.javaClass.simpleName}: ${e.message ?: "원인 미상"}"
            }
            done(translation, error, raw)
        }
    }

    private fun normalize(raw: String, source: String): String {
        val cleaned = raw.substringBefore("<end_of_turn>")
            .replace(Regex("(?i)^\\s*(korean|translation|번역)\\s*[:：]\\s*"), "")
            .replace(Regex("[\\r\\n]+"), " ")
            .trim().trim('"', '\'')
        if (cleaned.isEmpty() || cleaned.length > maxOf(100, source.length * 5)) return ""
        if (!cleaned.any { it in '\uAC00'..'\uD7A3' }) return ""
        return cleaned
    }

    fun close() {
        if (closed) return
        closed = true
        worker.execute {
            val old = engine
            engine = null
            if (old != null) try { old.close() } catch (e: Exception) {
                Log.w("GameTranslatorGemma", "Close failed", e)
            }
        }
        worker.shutdown()
    }

    companion object {
        private const val FILE_NAME = "Gemma3-1B-IT_multi-prefill-seq_q4_ekv4096.litertlm"
        fun modelFile(context: Context): File = File(context.filesDir, FILE_NAME)

        private fun prepareBundledModel(context: Context): File {
            val target = modelFile(context)
            check(target.isFile && target.length() > 500_000_000L) { "Gemma 모델 파일을 먼저 다운로드하세요" }
            return target
        }
    }
}
