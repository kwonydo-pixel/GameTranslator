package com.kwonydo.gametranslator

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File
import java.util.concurrent.Executors

/** One background thread owns the LiteRT-LM engine and each short-lived conversation. */
class GemmaEngine(private val context: Context) {
    private val worker = Executors.newSingleThreadExecutor()
    private var engine: LlmInference? = null
    @Volatile private var closed = false

    fun initialize(done: (Boolean, String) -> Unit) {
        if (closed) { done(false, "엔진 종료됨"); return }
        worker.execute {
            var message = "MediaPipe Gemma .task 모델 준비 완료"
            val success = try {
                if (engine == null) {
                    val model = prepareBundledModel(context)
                    val options = LlmInference.LlmInferenceOptions.builder()
                        .setModelPath(model.absolutePath)
                        .setMaxTokens(512)
                        .setMaxTopK(40)
                        .build()
                    val candidate = LlmInference.createFromOptions(context, options)
                    engine = candidate
                }
                true
            } catch (e: Throwable) {
                Log.e("GameTranslatorGemma", "MediaPipe initialization", e)
                message = "초기화 실패: ${e.javaClass.simpleName}: ${e.message ?: "원인 미상"}"
                false
            }
            done(success, message)
        }
    }

    fun translate(text: String, language: Int, done: (String, String?, String) -> Unit, contextHint: String = "") {
        if (closed) { done("", "Gemma 엔진 종료됨", ""); return }
        worker.execute {
            var raw = ""
            var error: String? = null
            var translation = ""
            try {
                val model = engine ?: throw IllegalStateException("Gemma가 초기화되지 않았습니다")
                val source = if (language == 0) "English" else "Japanese"
                val input = text.replace(Regex("[\\r\\n]+"), " ").trim().take(300)
                // MediaPipe .task inference; input is real user text.
                // Gemma instruction-tuned model: isolate user text from instructions.
                val prompt = """You are a translation engine for video games.
TASK: Translate the SOURCE_TEXT from $source into natural Korean.
RULES:
- Translate the SOURCE_TEXT, do not answer it or continue it.
- Return ONLY the Korean translation. No preface, quotes, examples or English.
- Keep game menu commands concise and natural.
- Do not assume an RPG genre or force ambiguous words to one meaning.
- Use surrounding text only to disambiguate, never to add new content.
- Never invent dialogue that is not in SOURCE_TEXT.
SURROUNDING_GAME_TEXT (may be empty):
$contextHint
SOURCE_TEXT_START
$input
SOURCE_TEXT_END
KOREAN_TRANSLATION:
""".trimIndent()
                raw = model.generateResponse(prompt)
                translation = normalize(raw, input)
                if (translation.isEmpty()) {
                    error = if (raw.isBlank()) "모델 응답 0자" else "한국어 번역 추출 실패"
                }
            } catch (e: Throwable) {
                Log.e("GameTranslatorGemma", "MediaPipe inference", e)
                error = "추론 실패: ${e.javaClass.simpleName}: ${e.message ?: "원인 미상"}"
            }
            done(translation, error, raw)
        }
    }

    fun correct(sourceText: String, mlTranslation: String, language: Int, done: (String, String?, String) -> Unit, contextHint: String = "") {
        if (closed) { done("", "Gemma 엔진 종료됨", ""); return }
        worker.execute {
            var raw = ""
            var result = ""
            var error: String? = null
            try {
                val model = engine ?: throw IllegalStateException("Gemma가 초기화되지 않았습니다")
                val sourceLanguage = if (language == 0) "English" else "Japanese"
                val original = sourceText.replace(Regex("[\r\n]+"), " ").trim().take(300)
                val draft = mlTranslation.replace(Regex("[\r\n]+"), " ").trim().take(400)
                val prompt = """You are a Korean video game localization editor.
TASK: Correct the draft Korean translation based on the original $sourceLanguage game text.
RULES:
- Output ONLY one natural Korean translation. No explanations, labels, quotes, or English.
- Preserve the original meaning; do not invent dialogue or add details.
- The draft may contain literal or incorrect wording. Fix it using the original text.
- Do not assume any specific game genre. Ambiguous terms depend on surrounding text.
- Keep every important noun and action from the original text.
- If context is insufficient, prefer a neutral accurate translation.
SURROUNDING_GAME_TEXT (may be empty):
$contextHint
ORIGINAL_TEXT_START
$original
ORIGINAL_TEXT_END
DRAFT_KOREAN_START
$draft
DRAFT_KOREAN_END
CORRECTED_KOREAN:
""".trimIndent()
                raw = model.generateResponse(prompt)
                result = normalize(raw, original)
                if (result.isBlank()) error = "한국어 교정 결과 추출 실패"
            } catch (e: Throwable) {
                Log.e("GameTranslatorGemma", "Correction inference", e)
                error = "교정 추론 실패: ${e.javaClass.simpleName}: ${e.message ?: "원인 미상"}"
            }
            done(result, error, raw)
        }
    }

    private fun normalize(raw: String, source: String): String {
        val cleaned = raw.substringBefore("<end_of_turn>")
            .replace(Regex("(?i)^\\s*(korean|translation|번역)\\s*[:：]\\s*"), "")
            .replace(Regex("[\\r\\n]+"), " ")
            .trim().trim('"', '\'')
        val normalized = cleaned.replace("\\n", " ").replace("\\r", " ").replace(Regex("\\s+"), " ").trim()
        if (normalized.isEmpty() || normalized.length > maxOf(100, source.length * 5)) return ""
        if (!normalized.any { it in '\uAC00'..'\uD7A3' }) return ""
        return normalized
    }

    fun close() {
        if (closed) return
        closed = true
        worker.execute {
            val old = engine
            engine = null
            if (old != null) try { old.close() } catch (e: Exception) {
                Log.w("GameTranslatorGemma", "Close failed", e)
            }
        }
        worker.shutdown()
    }

    companion object {
        private const val FILE_NAME = "Gemma3-1B-IT_multi-prefill-seq_q4_ekv2048.task"
        fun modelFile(context: Context): File = File(context.filesDir, FILE_NAME)

        private fun prepareBundledModel(context: Context): File {
            val target = modelFile(context)
            check(target.isFile && target.length() > 500_000_000L) { "Gemma 모델 파일을 먼저 다운로드하세요" }
            return target
        }
    }
}
