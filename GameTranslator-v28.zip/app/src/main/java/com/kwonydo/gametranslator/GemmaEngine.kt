package com.kwonydo.gametranslator

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File
import android.util.Log
import java.util.concurrent.Executors

/** Downloads a public, 4-bit Gemma 3 1B MediaPipe task and runs it locally. */
class GemmaEngine(private val context: Context) {
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var llm: LlmInference? = null

    fun initialize(done: (Boolean, String) -> Unit) {
        worker.execute {
            var detail = "모델 초기화 완료"
            val ok = try {
                val model = prepareBundledModel(context)
                val options = LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(model.absolutePath)
                    .setMaxTokens(1024)
                    .build()
                llm = LlmInference.createFromOptions(context, options)
                true
            } catch (e: Throwable) {
                Log.e("GameTranslatorGemma", "Initialization failed", e)
                detail = "초기화 실패: ${e.javaClass.simpleName}: ${e.message ?: "원인 미상"}"
                false
            }
            done(ok, detail)
        }
    }

    // Diagnostic build: retain the exact generated text BEFORE validation/cleanup.
    // This distinguishes inference/prompt failures from post-processing failures.
    fun translate(text: String, language: Int, done: (String, String?, String) -> Unit) {
        worker.execute {
            var error: String? = null
            var raw = ""
            val result = try {
                val source = if (language == 0) "English" else "Japanese"
                val cleaned = text.replace("\\n", " ").replace(Regex("[\r\n]+"), " ").trim().take(350)
                val prompt = "<start_of_turn>user\n" +
                    "Translate the following $source game text into natural Korean. " +
                    "Output only the Korean translation, with no explanation or extra text.\n" +
                    "Text: $cleaned\n<end_of_turn>\n<start_of_turn>model\n"
                val engine = llm ?: throw IllegalStateException("Gemma engine not initialized")
                raw = engine.generateResponse(prompt)
                Log.i("GameTranslatorGemma", "Raw inference (${raw.length} chars): ${raw.take(1200)}")
                val candidate = raw.trim().substringBefore("<end_of_turn>").substringBefore("<start_of_turn>")
                    .substringBefore("\n\n")
                    .replace(Regex("(?i)^(?:korean|translation|번역)\\s*[:：]\\s*"), "")
                    .replace(Regex("[\r\n]+"), " ").trim().trim('"', '\'')
                if (candidate.length > maxOf(90, cleaned.length * 3) ||
                    !candidate.any { it in '\uAC00'..'\uD7A3' } ||
                    candidate.contains("**") || candidate.contains("<source>")) {
                    error = "번역 형식 오류: 원본 응답을 아래 진단에서 확인하세요"
                    ""
                } else candidate
            } catch (e: Throwable) {
                Log.e("GameTranslatorGemma", "Inference failed", e)
                error = "추론 실패: ${e.javaClass.simpleName}: ${e.message ?: "원인 미상"}"
                ""
            }
            if (result.isBlank() && error == null) error = "모델 응답이 비어 있습니다"
            done(result, error, raw)
        }
    }

    fun close() { worker.execute { try { llm?.close() } catch (_: Exception) {} }; worker.shutdown() }

    companion object {
        private const val FILE_NAME = "Gemma3-1B-IT_multi-prefill-seq_q4_ekv2048.task"
        private const val EXPECTED_BYTES = 554661246L
        fun modelFile(context: Context): File = File(context.filesDir, FILE_NAME)
        private fun prepareBundledModel(context: Context): File {
            val target = modelFile(context)
            if (target.length() == EXPECTED_BYTES) return target
            val temporary = File(context.filesDir, "$FILE_NAME.tmp")
            try {
                context.assets.open(FILE_NAME).use { input ->
                    temporary.outputStream().use { output -> input.copyTo(output, 256 * 1024) }
                }
                check(temporary.length() == EXPECTED_BYTES) { "내장 모델 크기 오류" }
                if (target.exists()) target.delete()
                check(temporary.renameTo(target)) { "모델 설치 실패" }
            } finally { temporary.delete() }
            return target
        }
    }
}
