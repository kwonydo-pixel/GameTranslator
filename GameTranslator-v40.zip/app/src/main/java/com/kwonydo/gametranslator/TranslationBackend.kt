package com.kwonydo.gametranslator

/** Backend boundary for an on-device sentence translator (English/Japanese -> Korean). */
interface TranslationBackend {
    val isReady: Boolean
    fun translate(source: String, language: Int, done: (translation: String, error: String?) -> Unit)
    fun close()
}

/** Safe placeholder. Never fabricate a translation or silently use a network API. */
class UnavailableTranslationBackend : TranslationBackend {
    override val isReady = false
    override fun translate(source: String, language: Int, done: (String, String?) -> Unit) {
        done("", "slimt native engine and language models are not linked")
    }
    override fun close() {}
}
