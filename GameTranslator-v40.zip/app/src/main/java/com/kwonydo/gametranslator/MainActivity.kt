package com.kwonydo.gametranslator

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val captureCode = 1001
    private var language = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val saved = getSharedPreferences("translator_settings", MODE_PRIVATE)
        language = saved.getInt("language", 0).coerceIn(0, 1)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 32)
            setBackgroundColor(Color.rgb(20, 26, 40))
        }
        fun title(s: String) = TextView(this).apply { text=s; textSize=19f; setTextColor(Color.WHITE); setPadding(0,12,0,12) }
        root.addView(title("GameTranslator 0.39\n게임 화면 번역"))
        fun readableAdapter(items: List<String>): ArrayAdapter<String> = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            override fun getView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                return super.getView(position, convertView, parent).also { (it as? TextView)?.setTextColor(Color.WHITE) }
            }
            override fun getDropDownView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                return super.getDropDownView(position, convertView, parent).also {
                    (it as? TextView)?.setTextColor(Color.BLACK)
                    it.setBackgroundColor(Color.WHITE)
                }
            }
        }.apply { setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        fun selectorBackground(): GradientDrawable = GradientDrawable().apply {
            setColor(Color.rgb(40, 53, 75))
            cornerRadius = 18f
            setStroke(3, Color.rgb(91, 153, 245))
        }
        fun selectionLabel(text: String) = TextView(this).apply {
            this.text = text; textSize = 15f; setTextColor(Color.rgb(186, 208, 237))
            setPadding(0, 22, 0, 9)
        }
        root.addView(selectionLabel("번역 언어 선택  ▾"))
        val spinner = Spinner(this).apply {
            background = selectorBackground()
            setPadding(24, 12, 24, 12)
            minimumHeight = 112
        }
        spinner.adapter = readableAdapter(listOf("영어 → 한국어", "일본어 → 한국어"))
        spinner.onItemSelectedListener = object: android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) { language=position; saved.edit().putInt("language", position).apply() }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        spinner.setSelection(language)
        root.addView(spinner)
        root.addView(selectionLabel("번역 엔진: slimt 이식 준비 중 (아직 연결되지 않음)"))
        val status = title("v39 준비본: OCR·화면 선택 기능만 유지. 번역 엔진은 아직 미연결입니다.")
        val start = Button(this).apply { text="화면 번역 시작" }
        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "다른 앱 위에 표시 권한을 허용하고 돌아오세요", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), captureCode)
            }
        }
        root.addView(start)
        val stop = Button(this).apply { text="번역 종료" }
        stop.setOnClickListener { stopService(Intent(this, CaptureService::class.java)); status.text="번역 종료" }
        root.addView(stop)
        root.addView(status)
        root.addView(title("이 파일은 번역 가능한 APK가 아닌 엔진 교체용 준비본입니다."))
        root.addView(title("영역 선택과 화면 인식은 유지됩니다. slimt 네이티브 연결 후 번역이 활성화됩니다."))
        setContentView(root)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode==captureCode && resultCode==RESULT_OK && data!=null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("resultData", data)
                putExtra("language", language)
            }
            if (Build.VERSION.SDK_INT>=26) startForegroundService(service) else startService(service)
            Toast.makeText(this, "번역 시작! 다른 앱으로 이동하세요.", Toast.LENGTH_LONG).show()
        }
    }
}
