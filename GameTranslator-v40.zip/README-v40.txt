GameTranslator v40 SCAFFOLD (NOT A WORKING TRANSLATOR)

Removed: GemmaEngine.kt, LiteRT-LM dependency, model asset/download, Gemma diagnostic UI, model verification step.
Retained: ML Kit OCR, screen capture, region selection, overlays.
Added: TranslationBackend.kt interface and explicit unavailable backend.

This package is NOT a functioning translation app. Do not install over a working v38 unless you intentionally want to test the migration scaffold. APK build has not been tested.

NEXT: integrate slimt native arm64 library via JNI and validate EN->KO and JA->KO language packs. Then implement sentence grouping, translation cache, and layout sizing. No cloud API is allowed.

Sources: https://github.com/DavidVentura/offline-translator ; https://github.com/marcosholgado/translate-kit
