package com.kwonydo.gametranslator

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.view.Gravity
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val captureCode = 1001
    private var language = 0
    private var engine = 0
    private val downloadExecutor = Executors.newSingleThreadExecutor()
    private val modelFile get() = File(filesDir, "qwen.gguf")
    private val modelSource = "https://huggingface.co/second-state/Qwen3-0.6B-GGUF/resolve/main/Qwen3-0.6B-Q4_K_M.gguf?download=true"
    private var modelDownloading = false
    private lateinit var modelInfo: TextView
    private lateinit var downloadModel: Button
    private lateinit var tryModel: Button

    private fun modelValid(): Boolean = try {
        modelFile.isFile && modelFile.length() > 400_000_000 && modelFile.inputStream().use {
            val header = ByteArray(4)
            it.read(header) == 4 && String(header, Charsets.US_ASCII) == "GGUF"
        }
    } catch (_: Exception) { false }

    private fun refreshModelStatus(message: String? = null) {
        modelInfo.text = message ?: if (modelValid())
            "Qwen 모델 준비됨 (${modelFile.length() / 1_000_000} MB)"
        else "Qwen 모델 없음. 아래 버튼을 눌러 앱에서 다운로드하세요."
        downloadModel.isEnabled = !modelDownloading
        downloadModel.text = if (modelValid()) "Qwen 모델 다시 다운로드" else "Qwen 모델 다운로드 (약 484 MB)"
        tryModel.isEnabled = !modelDownloading && modelValid()
    }

    private fun downloadQwenModel() {
        if (modelDownloading) return
        modelDownloading = true
        refreshModelStatus("모델 다운로드 연결 중...")
        downloadExecutor.execute {
            val part = File(filesDir, "qwen.gguf.part")
            try {
                if (usableSpace() < 650_000_000L) throw Exception("저장 공간이 부족합니다 (650 MB 이상 필요)")
                val conn = URL(modelSource).openConnection() as HttpURLConnection
                conn.connectTimeout = 20000
                conn.readTimeout = 45000
                conn.instanceFollowRedirects = true
                conn.connect()
                if (conn.responseCode !in 200..299) throw Exception("다운로드 HTTP ${conn.responseCode}")
                val total = conn.contentLengthLong
                var done = 0L
                var lastUpdate = 0L
                conn.inputStream.use { input ->
                    FileOutputStream(part).use { output ->
                        val bytes = ByteArray(65536)
                        while (true) {
                            val n = input.read(bytes)
                            if (n == -1) break
                            output.write(bytes, 0, n)
                            done += n
                            val now = android.os.SystemClock.elapsedRealtime()
                            if (now - lastUpdate >= 400L) {
                                val label = if (total > 0) "모델 다운로드 ${done * 100 / total}% (${done / 1_000_000}/${total / 1_000_000} MB)"
                                            else "모델 다운로드 ${done / 1_000_000} MB"
                                runOnUiThread { modelInfo.text = label }
                                lastUpdate = now
                            }
                        }
                        output.fd.sync()
                    }
                }
                conn.disconnect()
                if (total > 0 && done != total) throw Exception("다운로드 용량 불일치")
                if (part.length() < 400_000_000L || part.inputStream().use { x ->
                    val b = ByteArray(4); x.read(b) != 4 || String(b, Charsets.US_ASCII) != "GGUF"
                }) throw Exception("모델 파일이 손상됐습니다")
                if (modelFile.exists() && !modelFile.delete()) throw Exception("기존 모델 삭제 실패")
                if (!part.renameTo(modelFile)) throw Exception("모델 파일 이동 실패")
                runOnUiThread {
                    modelDownloading = false
                    refreshModelStatus("모델 다운로드 완료 (${modelFile.length() / 1_000_000} MB). AI 시험 번역을 실행하세요.")
                }
            } catch (e: Exception) {
                part.delete()
                runOnUiThread {
                    modelDownloading = false
                    refreshModelStatus("다운로드 실패: ${e.message}. 다시 시도할 수 있습니다.")
                }
            }
        }
    }

    private fun usableSpace(): Long = filesDir.usableSpace

    private fun testQwen() {
        if (!modelValid()) { refreshModelStatus("먼저 Qwen 모델을 다운로드하세요."); return }
        tryModel.isEnabled = false
        modelInfo.text = "Qwen 모델 로딩 및 시험 번역 중... (첫 실행은 오래 걸릴 수 있음)"
        val backend = QwenTranslationBackend(applicationContext)
        // The backend queues the test after model loading on its own single worker.
        backend.translate("Choose your class before entering the dungeon.", 0) { translation, error ->
            runOnUiThread {
                refreshModelStatus(if (error != null) "AI 시험 실패: $error" else if (translation.isBlank())
                    "AI 응답이 비어 있습니다. 모델/추론 코드를 확인해야 합니다."
                    else "AI 시험 번역: $translation")
                tryModel.isEnabled = true
                backend.close()
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val saved = getSharedPreferences("translator_settings", MODE_PRIVATE)
        language = saved.getInt("language", 0).coerceIn(0, 1)
        engine = saved.getInt("engine", 0).coerceIn(0, 1)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 32)
            setBackgroundColor(Color.rgb(20, 26, 40))
        }
        fun title(s: String) = TextView(this).apply { text=s; textSize=19f; setTextColor(Color.WHITE); setPadding(0,12,0,12) }
        root.addView(title("GameTranslator 0.50\n오프라인 게임 화면 번역"))
        fun readableAdapter(items: List<String>): ArrayAdapter<String> = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            override fun getView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                return super.getView(position, convertView, parent).also { (it as? TextView)?.setTextColor(Color.WHITE) }
            }
            override fun getDropDownView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                return super.getDropDownView(position, convertView, parent).also {
                    (it as? TextView)?.setTextColor(Color.BLACK)
                    it.setBackgroundColor(Color.WHITE)
                }
            }
        }.apply { setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        fun selectorBackground(): GradientDrawable = GradientDrawable().apply {
            setColor(Color.rgb(40, 53, 75))
            cornerRadius = 18f
            setStroke(3, Color.rgb(91, 153, 245))
        }
        fun selectionLabel(text: String) = TextView(this).apply {
            this.text = text; textSize = 15f; setTextColor(Color.rgb(186, 208, 237))
            setPadding(0, 22, 0, 9)
        }
        root.addView(selectionLabel("번역 언어 선택  ▾"))
        val spinner = Spinner(this).apply {
            background = selectorBackground()
            setPadding(24, 12, 24, 12)
            minimumHeight = 112
        }
        spinner.adapter = readableAdapter(listOf("영어 → 한국어", "일본어 → 한국어"))
        spinner.onItemSelectedListener = object: android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) { language=position; saved.edit().putInt("language", position).apply() }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        spinner.setSelection(language)
        root.addView(spinner)
        root.addView(selectionLabel("번역 엔진 선택"))
        val engineSpinner = Spinner(this).apply { background = selectorBackground(); setPadding(24, 12, 24, 12) }
        engineSpinner.adapter = readableAdapter(listOf("ML Kit (기존)", "Qwen GGUF (실험)"))
        engineSpinner.setSelection(engine)
        engineSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                engine = position; saved.edit().putInt("engine", position).apply()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        root.addView(engineSpinner)
        modelInfo = title("Qwen 모델 상태 확인 중...")
        root.addView(modelInfo)
        downloadModel = Button(this).apply { text = "Qwen 모델 다운로드" }
        downloadModel.setOnClickListener { downloadQwenModel() }
        root.addView(downloadModel)
        tryModel = Button(this).apply { text = "AI 시험 번역 (게임 실행 전)" }
        tryModel.setOnClickListener { testQwen() }
        root.addView(tryModel)
        val chooseModel = Button(this).apply { text = "기존 GGUF 파일 가져오기 (선택)" }
        chooseModel.setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            }, 1002)
        }
        root.addView(chooseModel)
        refreshModelStatus()
        val status = title("첫 실행 시 인터넷으로 번역 모델을 다운로드합니다. 이후 오프라인 사용이 가능합니다.")
        val start = Button(this).apply { text="화면 번역 시작" }
        start.setOnClickListener {
            if (engine == 1 && !modelValid()) {
                Toast.makeText(this, "먼저 Qwen 모델을 다운로드하세요", Toast.LENGTH_LONG).show()
            } else if (engine == 1 && modelDownloading) {
                Toast.makeText(this, "모델 다운로드가 끝난 뒤 시작하세요", Toast.LENGTH_LONG).show()
            } else if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "다른 앱 위에 표시 권한을 허용하고 돌아오세요", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), captureCode)
            }
        }
        root.addView(start)
        val stop = Button(this).apply { text="번역 종료" }
        stop.setOnClickListener { stopService(Intent(this, CaptureService::class.java)); status.text="번역 종료" }
        root.addView(stop)
        root.addView(status)
        root.addView(title("v53: Qwen 오버레이 상태 진단"))
        root.addView(title("Qwen 번역은 먼저 완료된 문장부터 화면에 표시합니다.\n※ 첫 실행 시 모델 다운로드가 끝나야 번역이 시작됩니다."))
        setContentView(root)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1002 && resultCode == RESULT_OK && data?.data != null) {
            val uri = data.data!!
            Thread {
                try {
                    val file = java.io.File(filesDir, "qwen.gguf")
                    contentResolver.openInputStream(uri)!!.use { input -> file.outputStream().use { input.copyTo(it) } }
                    runOnUiThread { refreshModelStatus("GGUF 저장 완료. AI 시험 번역을 눌러보세요.") }
                } catch (e: Exception) {
                    runOnUiThread { refreshModelStatus("모델 복사 실패: ${e.message}") }
                }
            }.start()
            return
        }
        if (requestCode==captureCode && resultCode==RESULT_OK && data!=null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("resultData", data)
                putExtra("language", language)
                putExtra("engine", engine)
            }
            if (Build.VERSION.SDK_INT>=26) startForegroundService(service) else startService(service)
            Toast.makeText(this, "번역 시작! 다른 앱으로 이동하세요.", Toast.LENGTH_LONG).show()
        }
    }
}
