package com.kwonydo.gametranslator

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.File
import java.util.concurrent.Executors

/** Single-threaded native GGUF inference; no cloud API. */
class QwenTranslationBackend(context: Context) : TranslationBackend {
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val model = File(context.filesDir, "qwen.gguf")
    @Volatile private var handle = 0L
    @Volatile private var closed = false
    @Volatile private var initError: String? = null
    @Volatile private var loading = true
    val statusMessage: String get() = if (loading) "AI GGUF 모델 읽는 중" else
        if (isReady) "AI 준비됨" else "오류: ${initError ?: "모델을 읽지 못했습니다"}"
    init {
        worker.execute {
            if (!closed) {
                if (!model.isFile) initError = "모델 파일이 없습니다"
                else try {
                    handle = NativeQwen.load(model.absolutePath)
                    if (handle == 0L) initError = "GGUF 모델 로딩 실패 (메모리/파일 확인)"
                } catch (e: Throwable) { initError = "모델 로딩 오류: ${e.message}" }
            }
            loading = false
        }
    }
    override val isReady: Boolean get() = handle != 0L && !closed
    override fun isReadyFor(language: Int) = isReady && language in 0..1
    override fun translate(source: String, language: Int, done: (String, String?) -> Unit) = translateBatch(listOf(source), language) { list, err -> done(list.firstOrNull().orEmpty(), err) }
    override fun translateBatch(sources: List<String>, language: Int, done: (List<String>, String?) -> Unit) {
        worker.execute {
            if (!isReadyFor(language)) { main.post { done(emptyList(), initError ?: "Qwen 모델 로딩 실패") }; return@execute }
            val results = sources.map { source ->
                try {
                    // Qwen3 requires chat-template delimiters; /no_think avoids analysis generation.
                    val system = "You are a game translator. Translate the user's ${if (language == 0) "English" else "Japanese"} text into natural Korean. Return only Korean translation, with no explanations."
                    val prompt = "<|im_start|>system\n$system<|im_end|>\n<|im_start|>user\n/no_think\n$source<|im_end|>\n<|im_start|>assistant\n"
                    NativeQwen.generate(handle, prompt, 220)
                        .substringBefore("<|im_end|>").substringBefore("<|im_start|>")
                        .replace(Regex("<think>[\\s\\S]*?</think>"), "").trim()
                } catch (e: Throwable) {
                    android.util.Log.e("QwenTranslation", "Inference error", e)
                    ""
                }
            }
            main.post { done(results, if (results.all { it.isBlank() }) "Qwen이 빈 응답을 반환했습니다" else null) }
        }
    }
    override fun close() { closed = true; worker.execute { if (handle != 0L) { NativeQwen.unload(handle); handle = 0L } }; worker.shutdown() }
}
object NativeQwen {
    init { System.loadLibrary("qwen_jni") }
    external fun load(path: String): Long
    external fun generate(handle: Long, prompt: String, maxTokens: Int): String
    external fun unload(handle: Long)
}
