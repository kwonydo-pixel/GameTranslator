package com.kwonydo.gametranslator

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.File
import java.util.concurrent.Executors

/** Single-threaded native GGUF inference; no cloud API. */
class QwenTranslationBackend(context: Context) : TranslationBackend {
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val model = File(context.filesDir, "qwen.gguf")
    @Volatile private var handle = 0L
    @Volatile private var closed = false
    init {
        worker.execute { if (model.isFile && !closed) handle = try { NativeQwen.load(model.absolutePath) } catch (_: Exception) { 0L } }
    }
    override val isReady: Boolean get() = handle != 0L && !closed
    override fun isReadyFor(language: Int) = isReady && language in 0..1
    override fun translate(source: String, language: Int, done: (String, String?) -> Unit) = translateBatch(listOf(source), language) { list, err -> done(list.firstOrNull().orEmpty(), err) }
    override fun translateBatch(sources: List<String>, language: Int, done: (List<String>, String?) -> Unit) {
        worker.execute {
            if (!isReadyFor(language)) { main.post { done(emptyList(), "GGUF model not loaded") }; return@execute }
            val results = sources.map { source ->
                try {
                    val prompt = "Translate the following ${if (language == 0) "English" else "Japanese"} game text into natural Korean. Output ONLY the translation. Preserve meaning, do not explain.\nText: $source\nKorean:"
                    NativeQwen.generate(handle, prompt, 160).trim()
                } catch (_: Exception) { "" }
            }
            main.post { done(results, null) }
        }
    }
    override fun close() { closed = true; worker.execute { if (handle != 0L) { NativeQwen.unload(handle); handle = 0L } }; worker.shutdown() }
}
object NativeQwen {
    init { System.loadLibrary("qwen_jni") }
    external fun load(path: String): Long
    external fun generate(handle: Long, prompt: String, maxTokens: Int): String
    external fun unload(handle: Long)
}
