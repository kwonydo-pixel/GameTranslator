package com.kwonydo.gametranslator

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val captureCode = 1001
    private var language = 0
    private var engine = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val saved = getSharedPreferences("translator_settings", MODE_PRIVATE)
        language = saved.getInt("language", 0).coerceIn(0, 1)
        engine = saved.getInt("engine", 0).coerceIn(0, 1)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 32)
            setBackgroundColor(Color.rgb(20, 26, 40))
        }
        fun title(s: String) = TextView(this).apply { text=s; textSize=19f; setTextColor(Color.WHITE); setPadding(0,12,0,12) }
        root.addView(title("GameTranslator 0.48\n오프라인 게임 화면 번역"))
        fun readableAdapter(items: List<String>): ArrayAdapter<String> = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            override fun getView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                return super.getView(position, convertView, parent).also { (it as? TextView)?.setTextColor(Color.WHITE) }
            }
            override fun getDropDownView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                return super.getDropDownView(position, convertView, parent).also {
                    (it as? TextView)?.setTextColor(Color.BLACK)
                    it.setBackgroundColor(Color.WHITE)
                }
            }
        }.apply { setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        fun selectorBackground(): GradientDrawable = GradientDrawable().apply {
            setColor(Color.rgb(40, 53, 75))
            cornerRadius = 18f
            setStroke(3, Color.rgb(91, 153, 245))
        }
        fun selectionLabel(text: String) = TextView(this).apply {
            this.text = text; textSize = 15f; setTextColor(Color.rgb(186, 208, 237))
            setPadding(0, 22, 0, 9)
        }
        root.addView(selectionLabel("번역 언어 선택  ▾"))
        val spinner = Spinner(this).apply {
            background = selectorBackground()
            setPadding(24, 12, 24, 12)
            minimumHeight = 112
        }
        spinner.adapter = readableAdapter(listOf("영어 → 한국어", "일본어 → 한국어"))
        spinner.onItemSelectedListener = object: android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) { language=position; saved.edit().putInt("language", position).apply() }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        spinner.setSelection(language)
        root.addView(spinner)
        root.addView(selectionLabel("번역 엔진 선택"))
        val engineSpinner = Spinner(this).apply { background = selectorBackground(); setPadding(24, 12, 24, 12) }
        engineSpinner.adapter = readableAdapter(listOf("ML Kit (기존)", "Qwen GGUF (실험)"))
        engineSpinner.setSelection(engine)
        engineSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                engine = position; saved.edit().putInt("engine", position).apply()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        root.addView(engineSpinner)
        val modelInfo = title("Qwen 사용 전 GGUF 모델을 선택하세요. 모델은 앱 내부에 복사됩니다.")
        root.addView(modelInfo)
        val chooseModel = Button(this).apply { text = "GGUF 모델 파일 선택" }
        chooseModel.setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            }, 1002)
        }
        root.addView(chooseModel)
        val status = title("첫 실행 시 인터넷으로 번역 모델을 다운로드합니다. 이후 오프라인 사용이 가능합니다.")
        val start = Button(this).apply { text="화면 번역 시작" }
        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "다른 앱 위에 표시 권한을 허용하고 돌아오세요", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), captureCode)
            }
        }
        root.addView(start)
        val stop = Button(this).apply { text="번역 종료" }
        stop.setOnClickListener { stopService(Intent(this, CaptureService::class.java)); status.text="번역 종료" }
        root.addView(stop)
        root.addView(status)
        root.addView(title("v46: ML Kit 번역 엔진 비교 버전 · 문단 병합 유지"))
        root.addView(title("메뉴와 선택지는 분리하고, 화면별 번역 결과는 한꺼번에 표시합니다.\n※ 첫 실행 시 모델 다운로드가 끝나야 번역이 시작됩니다."))
        setContentView(root)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1002 && resultCode == RESULT_OK && data?.data != null) {
            val uri = data.data!!
            Thread {
                try {
                    val file = java.io.File(filesDir, "qwen.gguf")
                    contentResolver.openInputStream(uri)!!.use { input -> file.outputStream().use { input.copyTo(it) } }
                    runOnUiThread { Toast.makeText(this, "GGUF 저장 완료", Toast.LENGTH_LONG).show() }
                } catch (e: Exception) {
                    runOnUiThread { Toast.makeText(this, "모델 복사 실패: ${e.message}", Toast.LENGTH_LONG).show() }
                }
            }.start()
            return
        }
        if (requestCode==captureCode && resultCode==RESULT_OK && data!=null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("resultData", data)
                putExtra("language", language)
                putExtra("engine", engine)
            }
            if (Build.VERSION.SDK_INT>=26) startForegroundService(service) else startService(service)
            Toast.makeText(this, "번역 시작! 다른 앱으로 이동하세요.", Toast.LENGTH_LONG).show()
        }
    }
}
