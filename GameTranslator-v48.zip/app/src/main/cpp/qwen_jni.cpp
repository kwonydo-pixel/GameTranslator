#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include "llama.h"
struct Session { llama_model *model; llama_context *ctx; std::mutex mutex; };
extern "C" JNIEXPORT jlong JNICALL Java_com_kwonydo_gametranslator_NativeQwen_load(JNIEnv *env, jobject, jstring path) {
    const char *cpath=env->GetStringUTFChars(path,nullptr);
    llama_backend_init();
    auto params=llama_model_default_params();
    params.n_gpu_layers=0;
    llama_model *model=llama_model_load_from_file(cpath,params);
    env->ReleaseStringUTFChars(path,cpath);
    if(!model) return 0;
    auto cparams=llama_context_default_params();
    cparams.n_ctx=2048; cparams.n_batch=512; cparams.n_threads=4;
    llama_context *ctx=llama_init_from_model(model,cparams);
    if(!ctx) { llama_model_free(model); return 0; }
    return reinterpret_cast<jlong>(new Session{model,ctx});
}
extern "C" JNIEXPORT jstring JNICALL Java_com_kwonydo_gametranslator_NativeQwen_generate(JNIEnv *env,jobject,jlong ptr,jstring prompt,jint maxTokens) {
    auto *s=reinterpret_cast<Session*>(ptr); if(!s) return env->NewStringUTF("");
    std::lock_guard<std::mutex> lock(s->mutex);
    const char *raw=env->GetStringUTFChars(prompt,nullptr); std::string input(raw);env->ReleaseStringUTFChars(prompt,raw);
    const llama_vocab *vocab=llama_model_get_vocab(s->model);
    std::vector<llama_token> tokens(input.size()+16);
    int count=llama_tokenize(vocab,input.c_str(),input.size(),tokens.data(),tokens.size(),true,true);
    if(count<=0 || count>1500) return env->NewStringUTF("");
    tokens.resize(count);
    llama_kv_cache_clear(s->ctx);
    llama_batch batch=llama_batch_get_one(tokens.data(),count);
    if(llama_decode(s->ctx,batch)!=0) return env->NewStringUTF("");
    llama_sampler *sampler=llama_sampler_init_greedy();
    std::string output;
    for(int i=0;i<maxTokens;i++) {
        llama_token tok=llama_sampler_sample(sampler,s->ctx,-1);
        if(llama_vocab_is_eog(vocab,tok)) break;
        char buf[512];int n=llama_token_to_piece(vocab,tok,buf,sizeof(buf),0,true);
        if(n>0) output.append(buf,n);
        llama_batch one=llama_batch_get_one(&tok,1);
        if(llama_decode(s->ctx,one)!=0) break;
    }
    llama_sampler_free(sampler);
    return env->NewStringUTF(output.c_str());
}
extern "C" JNIEXPORT void JNICALL Java_com_kwonydo_gametranslator_NativeQwen_unload(JNIEnv*,jobject,jlong ptr) {
    auto *s=reinterpret_cast<Session*>(ptr);if(!s)return;
    llama_free(s->ctx);llama_model_free(s->model);delete s;
}
