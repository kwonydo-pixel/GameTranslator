package com.kwonydo.gametranslator

import android.app.*
import android.content.*
import android.content.res.Configuration
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.*
import android.text.TextUtils
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.nl.translate.*
import kotlin.math.*

class CaptureService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var translator: Translator? = null
    private var recognizer: com.google.mlkit.vision.text.TextRecognizer? = null
    private var bubble: View? = null
    private var menu: View? = null
    private var chooser: View? = null
    private val labels = mutableListOf<View>()
    private val regions = mutableListOf<RectF>() // Coordinates in the overlay's current window
    private var busy = false
    private var ready = false
    private var captureWidth = 0
    private var captureHeight = 0
    private var overlayWidth = 0
    private var overlayHeight = 0
    private var dpi = 0
    private var bubbleX = 0
    private var bubbleY = 150
    private var translationEnabled = true
    private var expanded = false
    private var generation = 0

    private val tick = object : Runnable {
        override fun run() {
            syncWindowSize()
            if (translationEnabled && ready && !busy && chooser == null && regions.isNotEmpty()) scan()
            handler.postDelayed(this, 1800)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        dpi = resources.displayMetrics.densityDpi
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null) return START_NOT_STICKY
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val channel = "game_translator"
        nm.createNotificationChannel(NotificationChannel(channel, "게임 화면 번역", NotificationManager.IMPORTANCE_LOW))
        val notification = Notification.Builder(this, channel)
            .setContentTitle("GameTranslator 작동 중")
            .setContentText("화면 가장자리의 버튼으로 조작")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, notification)

        val lang = intent?.getIntExtra("language", 0) ?: 0
        val source = if (lang == 0) TranslateLanguage.ENGLISH else TranslateLanguage.JAPANESE
        translator = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(source).setTargetLanguage(TranslateLanguage.KOREAN).build())
        recognizer = if (lang == 0) TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                     else TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        translator?.downloadModelIfNeeded()?.addOnSuccessListener { ready = true }
            ?.addOnFailureListener { toast("번역 모델 준비 실패") }

        @Suppress("DEPRECATION")
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("resultData", Intent::class.java)
        else intent?.getParcelableExtra("resultData")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(intent?.getIntExtra("resultCode", Activity.RESULT_OK) ?: Activity.RESULT_OK, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { handler.post { stopSelf() } }
            override fun onCapturedContentResize(width: Int, height: Int) {
                handler.post { resizeCapture(width, height) }
            }
        }, handler)
        syncWindowSize()
        resizeCapture(overlayWidth, overlayHeight, first = true)
        showBubble()
        handler.postDelayed(tick, 1800)
        return START_NOT_STICKY
    }

    private fun windowBounds(): Rect = if (Build.VERSION.SDK_INT >= 30) wm.currentWindowMetrics.bounds
        else { @Suppress("DEPRECATION") val d = wm.defaultDisplay; val p = Point(); @Suppress("DEPRECATION") d.getRealSize(p); Rect(0, 0, p.x, p.y) }

    private fun syncWindowSize() {
        val bounds = windowBounds()
        val w = bounds.width().coerceAtLeast(1)
        val h = bounds.height().coerceAtLeast(1)
        if (w == overlayWidth && h == overlayHeight) return
        val oldW = overlayWidth
        val oldH = overlayHeight
        if (oldW > 0 && oldH > 0) {
            regions.forEach { r ->
                r.set(r.left * w / oldW, r.top * h / oldH, r.right * w / oldW, r.bottom * h / oldH)
            }
            bubbleX = (bubbleX.toFloat() * w / oldW).roundToInt()
            bubbleY = (bubbleY.toFloat() * h / oldH).roundToInt()
        }
        overlayWidth = w; overlayHeight = h
        generation++
        clearLabels()
        if (chooser != null) {
            // Recreate the full-window selector after folding, rotation or split-screen resize.
            removeSafely(chooser); chooser = null
            selectRegions()
        }
        if (bubble != null) moveBubble(snap = true)
        if (menu != null) { removeSafely(menu); menu = null; expanded = false }
    }

    private fun resizeCapture(w: Int, h: Int, first: Boolean = false) {
        if (w <= 0 || h <= 0 || (w == captureWidth && h == captureHeight && !first)) return
        captureWidth = w; captureHeight = h
        val old = reader
        val next = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = next
        if (first) {
            virtualDisplay = projection?.createVirtualDisplay("GameTranslator", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, next.surface, null, handler)
        } else {
            virtualDisplay?.setSurface(null)
            virtualDisplay?.resize(w, h, dpi)
            virtualDisplay?.setSurface(next.surface)
        }
        old?.close()
        generation++
        clearLabels()
    }

    private fun params(w: Int, h: Int, touch: Boolean = true): WindowManager.LayoutParams {
        val flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            (if (touch) WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE else
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        return WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.LEFT }
    }

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).roundToInt()

    private fun showBubble() {
        val button = TextView(this).apply {
            text = "文A"; textSize = 17f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.rgb(28, 108, 215)); setStroke(dp(2), Color.CYAN)
            }
        }
        val p = params(dp(56), dp(56))
        p.x = bubbleX; p.y = bubbleY
        wm.addView(button, p); bubble = button
        var downX = 0f; var downY = 0f
        var startX = 0; var startY = 0; var dragged = false
        button.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = bubbleX; startY = bubbleY; dragged = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(event.rawX - downX) > dp(6) || abs(event.rawY - downY) > dp(6)) dragged = true
                    if (dragged) {
                        bubbleX = startX + (event.rawX - downX).roundToInt()
                        bubbleY = startY + (event.rawY - downY).roundToInt()
                        moveBubble(false)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (dragged) moveBubble(true) else toggleMenu()
                    true
                }
                else -> true
            }
        }
    }

    private fun moveBubble(snap: Boolean) {
        val v = bubble ?: return
        val size = dp(56)
        bubbleX = bubbleX.coerceIn(0, (overlayWidth - size).coerceAtLeast(0))
        bubbleY = bubbleY.coerceIn(0, (overlayHeight - size).coerceAtLeast(0))
        if (snap) bubbleX = if (bubbleX + size / 2 < overlayWidth / 2) 0 else (overlayWidth - size).coerceAtLeast(0)
        try { wm.updateViewLayout(v, (v.layoutParams as WindowManager.LayoutParams).apply { x = bubbleX; y = bubbleY }) } catch (_: Exception) {}
        if (menu != null) { removeSafely(menu); menu = null; expanded = false }
    }

    private fun toggleMenu() {
        if (expanded) { removeSafely(menu); menu = null; expanded = false; return }
        val bar = LinearLayout(this).apply {
            orientation = if (overlayWidth < dp(360)) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            setPadding(dp(3), dp(3), dp(3), dp(3))
            setBackgroundColor(Color.argb(235, 23, 34, 52))
        }
        fun addButton(text: String, action: () -> Unit) {
            bar.addView(Button(this).apply { this.text = text; textSize = 12f; setOnClickListener { toggleMenu(); action() } })
        }
        addButton(if (translationEnabled) "번역 OFF" else "번역 ON") {
            translationEnabled = !translationEnabled
            generation++
            clearLabels()
            toast(if (translationEnabled) "번역 ON" else "번역 OFF")
        }
        addButton("영역 선택") { selectRegions() }
        addButton("초기화") { regions.clear(); clearLabels(); toast("영역 초기화") }
        addButton("종료") { stopSelf() }
        val p = params(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
        val right = bubbleX < overlayWidth / 2
        // Put menu beneath bubble so it remains accessible in narrow split windows.
        p.x = if (right) 0 else max(0, overlayWidth - dp(320))
        p.y = (bubbleY + dp(60)).coerceAtMost(max(0, overlayHeight - dp(180)))
        wm.addView(bar, p); menu = bar; expanded = true
    }

    private fun selectRegions() {
        clearLabels()
        val selection = SelectionView(this, regions) { finish ->
            removeSafely(chooser); chooser = null
            if (finish) toast("${regions.size}개 영역 자동 번역 시작")
        }
        chooser = selection
        wm.addView(selection, params(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT))
    }

    private fun clearLabels() { labels.toList().forEach { removeSafely(it) }; labels.clear() }
    private fun removeSafely(view: View?) { if (view != null) try { wm.removeView(view) } catch (_: Exception) {} }

    // Hide previous translations before grabbing a new frame, so OCR cannot
    // mistake our own Korean overlay for the game's source text.
    private fun scan() {
        if (busy) return
        busy = true
        clearLabels()
        val gen = generation
        handler.postDelayed({
            if (gen != generation || chooser != null || !translationEnabled) { busy = false; return@postDelayed }
            val source = reader ?: run { busy = false; return@postDelayed }
            val image = try { source.acquireLatestImage() } catch (_: Exception) { null }
                ?: run { busy = false; return@postDelayed }
            try {
                val plane = image.planes[0]
                val paddedWidth = plane.rowStride / plane.pixelStride
                val bitmap = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
                bitmap.copyPixelsFromBuffer(plane.buffer)
                val cropped = Bitmap.createBitmap(bitmap, 0, 0, image.width, image.height)
                image.close(); bitmap.recycle()
                val imageW = cropped.width; val imageH = cropped.height
                recognizer?.process(InputImage.fromBitmap(cropped, 0))?.addOnSuccessListener { result ->
                    cropped.recycle()
                    if (gen != generation || chooser != null || !translationEnabled) { busy = false; return@addOnSuccessListener }
                    val sx = overlayWidth.toFloat() / imageW
                    val sy = overlayHeight.toFloat() / imageH
                    val tasks = result.textBlocks.flatMap { it.lines }.mapNotNull { line ->
                        val r = line.boundingBox ?: return@mapNotNull null
                        val text = line.text.trim()
                        if (text.isBlank() || !text.any { it.isLetter() }) return@mapNotNull null
                        val cx = r.exactCenterX() * sx; val cy = r.exactCenterY() * sy
                        val region = regions.firstOrNull { it.contains(cx, cy) } ?: return@mapNotNull null
                        Triple(text, Rect(r), RectF(region))
                    }.take(30)
                    if (tasks.isEmpty()) { busy = false; return@addOnSuccessListener }
                    var pending = tasks.size
                    tasks.forEach { (text, rect, region) ->
                        translator?.translate(text)?.addOnSuccessListener { translated ->
                            if (gen == generation && translationEnabled && chooser == null && translated.isNotBlank())
                                showLineLabel(translated, rect, region, imageW, imageH)
                        }?.addOnCompleteListener {
                            pending--
                            if (pending == 0) busy = false
                        }
                    }
                }?.addOnFailureListener { cropped.recycle(); busy = false }
            } catch (_: Exception) {
                try { image.close() } catch (_: Exception) {}
                busy = false
            }
        }, 160)
    }

    private fun showLineLabel(value: String, rect: Rect, region: RectF, imageW: Int, imageH: Int) {
        if (overlayWidth <= 0 || overlayHeight <= 0) return
        val sx = overlayWidth.toFloat() / imageW
        val sy = overlayHeight.toFloat() / imageH
        val left = (rect.left * sx).roundToInt().coerceAtLeast(region.left.roundToInt()).coerceAtLeast(0)
        val top = (rect.top * sy).roundToInt().coerceAtLeast(region.top.roundToInt()).coerceAtLeast(0)
        val right = region.right.roundToInt().coerceAtMost(overlayWidth)
        val bottom = region.bottom.roundToInt().coerceAtMost(overlayHeight)
        if (right <= left || bottom <= top) return
        // Each OCR line gets its own anchored label, not a giant region-wide box.
        val originalWidth = max(dp(36), (rect.width() * sx).roundToInt())
        val maxWidth = right - left
        val preferred = max(originalWidth, dp(110)).coerceAtMost(maxWidth)
        val pad = dp(2)
        val label = TextView(this).apply {
            text = value
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(18, 23, 32))
            setPadding(pad, 0, pad, 0)
            includeFontPadding = false
            gravity = Gravity.TOP or Gravity.START
            breakStrategy = android.text.Layout.BREAK_STRATEGY_HIGH_QUALITY
        }
        val maxHeight = bottom - top
        val widthSpec = View.MeasureSpec.makeMeasureSpec(preferred, View.MeasureSpec.EXACTLY)
        val heightSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        // Prefer legibility, but avoid covering other menu items when text is long.
        val originalHeight = max(dp(14), (rect.height() * sy).roundToInt())
        val budget = min(maxHeight, max(originalHeight * 2, dp(34)))
        for (fontSize in listOf(15f, 14f, 13f, 12f, 11f, 10f, 9f, 8f)) {
            label.textSize = fontSize
            label.measure(widthSpec, heightSpec)
            if (label.measuredHeight <= budget) break
        }
        val height = label.measuredHeight.coerceAtLeast(dp(12)).coerceAtMost(budget)
        val p = params(preferred, height, false)
        p.x = left; p.y = top
        try { wm.addView(label, p); labels.add(label) } catch (_: Exception) {}
    }

    private fun toast(message: String) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show() }
    override fun onConfigurationChanged(newConfig: Configuration) { super.onConfigurationChanged(newConfig); handler.post { syncWindowSize() } }
    override fun onDestroy() {
        handler.removeCallbacks(tick)
        clearLabels(); removeSafely(chooser); removeSafely(menu); removeSafely(bubble)
        virtualDisplay?.release(); reader?.close(); projection?.stop()
        translator?.close(); recognizer?.close()
        super.onDestroy()
    }
}

private class SelectionView(context: Context, private val regions: MutableList<RectF>,
                            private val finish: (Boolean) -> Unit) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var sx = 0f; private var sy = 0f; private var ex = 0f; private var ey = 0f
    private var drawing = false
    private val density = resources.displayMetrics.density
    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.argb(80, 0, 0, 0))
        paint.color = Color.CYAN; paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f * density
        regions.forEach { canvas.drawRect(it, paint) }
        if (drawing) canvas.drawRect(sx, sy, ex, ey, paint)
        paint.style = Paint.Style.FILL; paint.color = Color.WHITE; paint.textSize = 16f * density
        canvas.drawText("드래그: 영역 추가", 12f * density, 35f * density, paint)
        paint.color = Color.rgb(35, 110, 210)
        val buttonW = 86f * density; val buttonH = 52f * density
        canvas.drawRoundRect(width - buttonW - 8f * density, 8f * density,
            width - 8f * density, buttonH + 8f * density, 12f * density, 12f * density, paint)
        paint.color = Color.WHITE; paint.textSize = 20f * density
        canvas.drawText("완료", width - buttonW + 9f * density, 41f * density, paint)
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (event.x > width - 100f * density && event.y < 65f * density) { finish(true); return true }
                sx = event.x; sy = event.y; ex = sx; ey = sy; drawing = true; invalidate(); return true
            }
            MotionEvent.ACTION_MOVE -> { if (drawing) { ex = event.x; ey = event.y; invalidate() }; return true }
            MotionEvent.ACTION_UP -> {
                if (drawing) {
                    ex = event.x; ey = event.y; drawing = false
                    val r = RectF(min(sx, ex), min(sy, ey), max(sx, ex), max(sy, ey))
                    if (r.width() > 25f * density && r.height() > 16f * density) regions.add(r)
                    invalidate()
                }
                return true
            }
        }
        return true
    }
}
