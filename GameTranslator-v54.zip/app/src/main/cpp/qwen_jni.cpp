#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include <chrono>
#include <algorithm>
#include "llama.h"

struct Session { llama_model *model; llama_context *ctx; std::mutex mutex; };
static jstring result(JNIEnv *env, const std::string &s) {
    // NewStringUTF does not accept arbitrary UTF-8 NUL bytes.
    return env->NewStringUTF(s.c_str());
}
extern "C" JNIEXPORT jlong JNICALL Java_com_kwonydo_gametranslator_NativeQwen_load(JNIEnv *env, jobject, jstring path) {
    const char *cpath = env->GetStringUTFChars(path, nullptr);
    llama_backend_init();
    auto params = llama_model_default_params();
    params.n_gpu_layers = 0;
    llama_model *model = llama_model_load_from_file(cpath, params);
    env->ReleaseStringUTFChars(path, cpath);
    if (!model) return 0;
    auto cp = llama_context_default_params();
    cp.n_ctx = 2048;
    cp.n_batch = 512;
    cp.n_ubatch = 256;
    cp.n_threads = 4;
    cp.n_threads_batch = 4;
    llama_context *ctx = llama_init_from_model(model, cp);
    if (!ctx) { llama_model_free(model); return 0; }
    return reinterpret_cast<jlong>(new Session{model, ctx});
}
extern "C" JNIEXPORT jstring JNICALL Java_com_kwonydo_gametranslator_NativeQwen_generate(JNIEnv *env, jobject, jlong ptr, jstring prompt, jint maxTokens) {
    auto *s = reinterpret_cast<Session*>(ptr);
    if (!s) return result(env, "QWEN_ERROR: 모델이 로드되지 않았습니다");
    std::lock_guard<std::mutex> lock(s->mutex);
    const char *raw = env->GetStringUTFChars(prompt, nullptr);
    std::string input(raw);
    env->ReleaseStringUTFChars(prompt, raw);
    const auto *vocab = llama_model_get_vocab(s->model);
    std::vector<llama_token> tokens(input.size() + 64);
    int count = llama_tokenize(vocab, input.c_str(), (int32_t) input.size(), tokens.data(), (int32_t) tokens.size(), true, true);
    if (count <= 0 || count > 1600) return result(env, "QWEN_ERROR: 입력 토큰 수가 제한을 초과했습니다");
    tokens.resize(count);
    llama_memory_clear(llama_get_memory(s->ctx), true);
    // A prompt may exceed n_batch. Decode in chunks, not one oversized batch.
    constexpr int chunk = 256;
    for (int offset = 0; offset < count; offset += chunk) {
        int n = std::min(chunk, count - offset);
        llama_batch batch = llama_batch_get_one(tokens.data() + offset, n);
        if (llama_decode(s->ctx, batch) != 0) return result(env, "QWEN_ERROR: 프롬프트 처리에 실패했습니다");
    }
    llama_sampler *sampler = llama_sampler_init_greedy();
    std::string output;
    const int limit = std::clamp((int)maxTokens, 1, 112);
    const auto start = std::chrono::steady_clock::now();
    bool timedOut = false;
    for (int i = 0; i < limit; ++i) {
        if (std::chrono::steady_clock::now() - start > std::chrono::seconds(24)) { timedOut = true; break; }
        llama_token tok = llama_sampler_sample(sampler, s->ctx, -1);
        if (llama_vocab_is_eog(vocab, tok)) break;
        char buf[1024];
        int n = llama_token_to_piece(vocab, tok, buf, sizeof(buf), 0, true);
        if (n > 0) output.append(buf, n);
        llama_batch one = llama_batch_get_one(&tok, 1);
        if (llama_decode(s->ctx, one) != 0) { if (output.empty()) output = "QWEN_ERROR: 생성 중 디코딩 실패"; break; }
    }
    llama_sampler_free(sampler);
    if (timedOut && output.empty()) return result(env, "QWEN_ERROR: 토큰 생성 시간 초과 (24초)");
    if (output.empty()) return result(env, "QWEN_ERROR: 생성된 토큰이 없습니다");
    return result(env, output);
}
extern "C" JNIEXPORT void JNICALL Java_com_kwonydo_gametranslator_NativeQwen_unload(JNIEnv*, jobject, jlong ptr) {
    auto *s = reinterpret_cast<Session*>(ptr);
    if (!s) return;
    llama_free(s->ctx); llama_model_free(s->model); delete s;
}
